#!/bin/bash

# AI 实践看板 - GitHub 推送脚本
# 使用方法：bash push-to-github.sh

set -e

echo "================================"
echo "🚀 AI 实践看板 - GitHub 推送"
echo "================================"
echo ""

# 获取用户信息
read -p "请输入你的 GitHub 用户名（如 uxsongwenjun）: " GITHUB_USER

if [ -z "$GITHUB_USER" ]; then
  echo "❌ 用户名不能为空"
  exit 1
fi

REPO_NAME="ai-practice-hub"
REPO_URL="https://github.com/${GITHUB_USER}/${REPO_NAME}.git"

echo ""
echo "📋 确认以下信息："
echo "  GitHub 用户名: $GITHUB_USER"
echo "  仓库 URL: $REPO_URL"
echo ""

# 检查远程配置
if git remote | grep -q origin; then
  echo "⚠️  检测到已有 origin 远程配置"
  read -p "是否删除现有的 origin？(y/n): " -n 1 REMOVE_ORIGIN
  echo ""

  if [[ $REMOVE_ORIGIN == "y" || $REMOVE_ORIGIN == "Y" ]]; then
    git remote remove origin
    echo "✅ 已删除旧的 origin 配置"
  else
    echo "ℹ️  使用现有的 origin 配置"
  fi
fi

# 添加新的远程仓库
echo ""
echo "⏳ 正在添加远程仓库..."
git remote add origin "$REPO_URL" 2>/dev/null || git remote set-url origin "$REPO_URL"
echo "✅ 远程仓库已配置"

# 显示当前分支
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
echo ""
echo "📌 当前分支: $CURRENT_BRANCH"

# 推送代码
echo ""
echo "⏳ 正在推送代码到 GitHub..."
echo "  （如果提示输入密码，请输入你的 GitHub Personal Access Token）"
echo ""

git push -u origin "$CURRENT_BRANCH"

echo ""
echo "✅ 推送成功！"
echo ""
echo "📍 仓库地址: https://github.com/${GITHUB_USER}/${REPO_NAME}"
echo ""
echo "接下来你可以："
echo "  1. 在 GitHub 网页中查看你的仓库"
echo "  2. 与团队成员分享仓库链接"
echo "  3. 使用 Docker 部署应用"
echo ""
echo "Docker 快速开始:"
echo "  docker build -t ai-practice-hub:latest ."
echo "  docker run -p 3000:3000 -v \$(pwd)/data:/app/data ai-practice-hub:latest"
echo ""
echo "================================"
