import { useState, useMemo, useRef } from "react";

const CATEGORIES = ["需求转译", "UI生成", "视觉探索", "动效生成", "走查验收", "代码交付", "素材批量", "竞品分析", "用研提效", "其他"];
const TOOLS = ["Claude", "Gemini Pro", "Figma Make", "即梦", "Midjourney", "Cursor", "nano banana", "Lovart", "Liblib", "seedance", "OpenClaw", "Stitch", "Tapnow", "其他"];
const RATINGS = ["🔥 强烈推荐", "👍 有效果", "🤔 一般", "👎 不推荐"];

const DEMO_DATA = [
  { id: 1, author: "小林", date: "2026-03-21", category: "需求转译", tool: "Claude", title: "PRD自动提取交互要点", desc: "把12页PRD丢给Claude，10分钟出交互要点清单，以前要读1小时。准确率约80%，关键交互节点基本没遗漏，细节需要人工review。", prompt: "你是一名资深交互设计师，请阅读以下PRD文档，提取所有涉及用户交互的功能点，按优先级排列，标注交互类型（点击/滑动/长按等）和异常状态处理...", timeSaved: 50, rating: "🔥 强烈推荐", likes: 12, images: [], beforeAfter: false },
  { id: 2, author: "阿杰", date: "2026-03-20", category: "素材批量", tool: "即梦", title: "会员活动Banner批量生成", desc: "用即梦+固定Prompt模板，一次生成8张不同风格的会员活动Banner。关键点：先在Prompt里定义好品牌色#E60026和字体规范，生成的一致性就高很多。", prompt: "设计一张网易云音乐会员活动Banner，尺寸1080x540，风格：赛博朋克，主色调：黑金配#E60026点缀，需包含文字区域预留...", timeSaved: 720, rating: "🔥 强烈推荐", likes: 24, images: ["https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=600&h=300&fit=crop", "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=600&h=300&fit=crop"], beforeAfter: true, beforeLabel: "传统流程2天", afterLabel: "AI辅助2小时" },
  { id: 3, author: "Mia", date: "2026-03-19", category: "UI生成", tool: "Figma Make", title: "播放器改版初稿AI生成", desc: "用Figma Make基于设计系统出播放器改版初稿。生成了3个方向，布局合理性约70%，组件使用基本正确。最大的价值是省了视觉探索时间，设计师可以直接在AI稿上精修。", prompt: "基于现有播放器组件库，生成3种不同风格的改版方案，保持底部Tab和播放控制栏位置不变...", timeSaved: 180, rating: "👍 有效果", likes: 8, images: ["https://images.unsplash.com/photo-1611339555312-e607c8352fd7?w=400&h=800&fit=crop"], beforeAfter: false },
  { id: 4, author: "你", date: "2026-03-22", category: "竞品分析", tool: "Gemini Pro", title: "竞品会员权益对比表自动生成", desc: "5个竞品截图丢给Gemini Pro，自动生成功能对比矩阵。识别准确率约85%，价格信息偶尔抓错，需人工复核。但整体框架和维度提取很准。", prompt: "分析以下5个音乐App的会员权益页面截图，输出对比表格。维度包括：价格层级、核心权益、差异化功能、视觉呈现方式...", timeSaved: 120, rating: "👍 有效果", likes: 6, images: [], beforeAfter: false },
  { id: 5, author: "小周", date: "2026-03-18", category: "动效生成", tool: "seedance", title: "播放器转场动效方案", desc: "seedance2.0生成播放器页面切换过渡动效。可以指定缓动曲线类型、时长、图层关系。输出的动效参数可以直接给开发用，省了以前AE导出再标注的流程。", prompt: "生成一个音乐播放器从列表页到播放页的转场动效，要求：缓入缓出，时长300ms，封面图从列表缩略图放大到全屏...", timeSaved: 240, rating: "🔥 强烈推荐", likes: 15, images: ["https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&h=400&fit=crop"], beforeAfter: false },
];

function StatCard({ label, value, sub, accent }) {
  return (
    <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 14, padding: "20px 22px" }}>
      <div style={{ fontSize: 11, color: "#666", marginBottom: 8, letterSpacing: 0.5, textTransform: "uppercase" }}>{label}</div>
      <div style={{ fontSize: 32, fontWeight: 800, color: accent || "#e8e8f0", lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: "#555", marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

function MediaGallery({ images, beforeAfter, beforeLabel, afterLabel }) {
  if (!images || images.length === 0) return null;
  if (beforeAfter && images.length >= 2) {
    return (
      <div style={{ marginTop: 14 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 3, borderRadius: 10, overflow: "hidden", position: "relative" }}>
          <div style={{ position: "relative" }}>
            <img src={images[0]} alt="before" style={{ width: "100%", height: 180, objectFit: "cover", display: "block", filter: "saturate(0.4)" }} />
            <div style={{ position: "absolute", bottom: 8, left: 8, background: "rgba(0,0,0,0.7)", borderRadius: 4, padding: "3px 8px", fontSize: 10, color: "#f87171", fontWeight: 600 }}>BEFORE · {beforeLabel}</div>
          </div>
          <div style={{ position: "relative" }}>
            <img src={images[1]} alt="after" style={{ width: "100%", height: 180, objectFit: "cover", display: "block" }} />
            <div style={{ position: "absolute", bottom: 8, left: 8, background: "rgba(0,0,0,0.7)", borderRadius: 4, padding: "3px 8px", fontSize: 10, color: "#34d399", fontWeight: 600 }}>AFTER · {afterLabel}</div>
          </div>
          <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "#0a0a0f", border: "2px solid rgba(255,255,255,0.15)", borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, zIndex: 2 }}>→</div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ marginTop: 14, display: "flex", gap: 6, overflowX: "auto", paddingBottom: 4 }}>
      {images.map((src, i) => (
        <img key={i} src={src} alt={`案例图${i + 1}`} style={{ height: 160, borderRadius: 8, objectFit: "cover", flexShrink: 0, border: "1px solid rgba(255,255,255,0.06)" }} />
      ))}
    </div>
  );
}

function CaseCard({ item, onLike }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div style={{ background: "rgba(255,255,255,0.015)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 14, overflow: "hidden", transition: "border-color 0.2s" }} onMouseEnter={e => e.currentTarget.style.borderColor = "rgba(99,102,241,0.3)"} onMouseLeave={e => e.currentTarget.style.borderColor = "rgba(255,255,255,0.06)"}>
      <MediaGallery images={item.images} beforeAfter={item.beforeAfter} beforeLabel={item.beforeLabel} afterLabel={item.afterLabel} />
      <div style={{ padding: "16px 20px 18px", cursor: "pointer" }} onClick={() => setExpanded(!expanded)}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <span style={{ fontSize: 10, background: "rgba(99,102,241,0.15)", color: "#818cf8", padding: "2px 8px", borderRadius: 4, fontWeight: 500 }}>{item.category}</span>
            <span style={{ fontSize: 10, background: "rgba(52,211,153,0.12)", color: "#34d399", padding: "2px 8px", borderRadius: 4, fontWeight: 500 }}>{item.tool}</span>
            {item.hasVideo && <span style={{ fontSize: 10, background: "rgba(251,146,60,0.12)", color: "#fb923c", padding: "2px 8px", borderRadius: 4, fontWeight: 500 }}>含视频</span>}
          </div>
          <span style={{ fontSize: 11, color: "#444", flexShrink: 0 }}>{item.date}</span>
        </div>
        <div style={{ fontSize: 16, fontWeight: 700, color: "#e8e8f0", marginBottom: 6, lineHeight: 1.4 }}>{item.title}</div>
        <div style={{ fontSize: 13, color: "#777", lineHeight: 1.7, marginBottom: 12 }}>{item.desc}</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <span style={{ fontSize: 12, color: "#555", fontWeight: 500 }}>by {item.author}</span>
            <span style={{ fontSize: 12, color: "#fb923c", fontWeight: 600 }}>省 {item.timeSaved >= 60 ? `${Math.round(item.timeSaved / 60)}h` : `${item.timeSaved}min`}</span>
            <span style={{ fontSize: 12 }}>{item.rating}</span>
          </div>
          <button onClick={e => { e.stopPropagation(); onLike(item.id); }} style={{ background: "none", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "5px 12px", color: "#777", fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, transition: "all 0.15s" }} onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(99,102,241,0.4)"; e.currentTarget.style.color = "#818cf8"; }} onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "#777"; }}>
            👍 {item.likes}
          </button>
        </div>
        {expanded && item.prompt && (
          <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid rgba(255,255,255,0.05)" }}>
            <div style={{ fontSize: 10, color: "#555", marginBottom: 6, letterSpacing: 1, textTransform: "uppercase", fontWeight: 600 }}>Prompt / 方法</div>
            <div style={{ fontSize: 12, color: "#999", background: "rgba(0,0,0,0.25)", borderRadius: 8, padding: "12px 14px", lineHeight: 1.7, fontFamily: "'JetBrains Mono', monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", border: "1px solid rgba(255,255,255,0.04)" }}>{item.prompt}</div>
            <button onClick={e => { e.stopPropagation(); navigator.clipboard?.writeText(item.prompt); }} style={{ marginTop: 8, background: "rgba(99,102,241,0.12)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 6, padding: "6px 14px", color: "#818cf8", fontSize: 11, cursor: "pointer", fontWeight: 500 }}>
              复制 Prompt
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function ImageUploader({ images, onChange }) {
  const fileRef = useRef(null);
  const addImage = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(f => {
      const reader = new FileReader();
      reader.onload = (ev) => onChange(prev => [...prev, { url: ev.target.result, type: f.type.startsWith("video") ? "video" : "image", name: f.name }]);
      reader.readAsDataURL(f);
    });
  };
  return (
    <div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
        {images.map((img, i) => (
          <div key={i} style={{ position: "relative", width: 100, height: 100, borderRadius: 8, overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)" }}>
            {img.type === "video" ? (
              <div style={{ width: "100%", height: "100%", background: "rgba(251,146,60,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#fb923c", flexDirection: "column", gap: 4 }}>
                <span style={{ fontSize: 20 }}>▶</span>
                <span>{img.name.slice(0, 12)}</span>
              </div>
            ) : (
              <img src={img.url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            )}
            <button onClick={() => onChange(prev => prev.filter((_, j) => j !== i))} style={{ position: "absolute", top: 4, right: 4, width: 18, height: 18, borderRadius: "50%", background: "rgba(0,0,0,0.7)", border: "none", color: "#999", fontSize: 10, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
          </div>
        ))}
        <button onClick={() => fileRef.current?.click()} style={{ width: 100, height: 100, borderRadius: 8, border: "1px dashed rgba(255,255,255,0.12)", background: "none", color: "#555", fontSize: 12, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, transition: "border-color 0.2s" }} onMouseEnter={e => e.currentTarget.style.borderColor = "rgba(99,102,241,0.4)"} onMouseLeave={e => e.currentTarget.style.borderColor = "rgba(255,255,255,0.12)"}>
          <span style={{ fontSize: 20, lineHeight: 1 }}>+</span>
          <span>图片/视频</span>
        </button>
      </div>
      <input ref={fileRef} type="file" accept="image/*,video/*" multiple onChange={addImage} style={{ display: "none" }} />
      <div style={{ fontSize: 11, color: "#444" }}>支持图片和视频，可上传Before/After对比图、效果截图、录屏等</div>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("browse");
  const [cases, setCases] = useState(DEMO_DATA);
  const [filterCat, setFilterCat] = useState("全部");
  const [filterTool, setFilterTool] = useState("全部");
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ author: "", category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0], beforeAfter: false });
  const [uploadedImages, setUploadedImages] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [viewMode, setViewMode] = useState("list");

  const filtered = useMemo(() => {
    return cases.filter(c => {
      if (filterCat !== "全部" && c.category !== filterCat) return false;
      if (filterTool !== "全部" && c.tool !== filterTool) return false;
      if (search && !c.title.includes(search) && !c.desc.includes(search) && !c.author.includes(search)) return false;
      return true;
    }).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [cases, filterCat, filterTool, search]);

  const stats = useMemo(() => {
    const thisWeek = cases.filter(c => { const d = new Date(c.date); const now = new Date(); return (now - d) / 864e5 <= 7; });
    const totalMin = cases.reduce((s, c) => s + c.timeSaved, 0);
    const authors = new Set(cases.map(c => c.author));
    const topCase = [...cases].sort((a, b) => b.likes - a.likes)[0];
    const toolCounts = Object.entries(cases.reduce((a, c) => { a[c.tool] = (a[c.tool] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    const catCounts = Object.entries(cases.reduce((a, c) => { a[c.category] = (a[c.category] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    return { total: cases.length, thisWeek: thisWeek.length, totalHours: Math.round(totalMin / 60), totalMin, authors: authors.size, topCase, toolCounts, catCounts };
  }, [cases]);

  const handleSubmit = () => {
    if (!form.title || !form.desc || !form.author) return;
    const imgs = uploadedImages.map(i => i.url);
    const hasVideo = uploadedImages.some(i => i.type === "video");
    const newCase = { ...form, id: Date.now(), date: new Date().toISOString().slice(0, 10), timeSaved: parseInt(form.timeSaved) || 0, likes: 0, images: imgs, hasVideo, beforeLabel: form.beforeAfter ? "改造前" : undefined, afterLabel: form.beforeAfter ? "改造后" : undefined };
    setCases(prev => [newCase, ...prev]);
    setForm({ author: "", category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0], beforeAfter: false });
    setUploadedImages([]);
    setSubmitted(true);
    setTimeout(() => { setSubmitted(false); setTab("browse"); }, 1500);
  };

  const handleLike = (id) => setCases(prev => prev.map(c => c.id === id ? { ...c, likes: c.likes + 1 } : c));

  const generateReport = () => {
    const thisWeek = cases.filter(c => (new Date() - new Date(c.date)) / 864e5 <= 7);
    const totalMin = thisWeek.reduce((s, c) => s + c.timeSaved, 0);
    const authors = [...new Set(thisWeek.map(c => c.author))];
    const top3 = [...thisWeek].sort((a, b) => b.likes - a.likes).slice(0, 3);
    const toolCount = Object.entries(thisWeek.reduce((a, c) => { a[c.tool] = (a[c.tool] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    const withImages = thisWeek.filter(c => c.images?.length > 0).length;
    let r = `📊 设计团队 AI 实践周报\n${"═".repeat(32)}\n\n`;
    r += `📅 周期：最近7天\n👥 参与：${authors.length}人（${authors.join("、")}）\n📝 案例：${thisWeek.length}条（含${withImages}条视觉案例）\n⏱️ 节省：约${Math.round(totalMin / 60)}小时\n\n`;
    r += `🏆 Top 案例\n`;
    top3.forEach((c, i) => { r += `  ${i + 1}. 「${c.title}」by ${c.author}\n     ${c.desc.slice(0, 50)}...\n     省时${c.timeSaved >= 60 ? Math.round(c.timeSaved / 60) + "h" : c.timeSaved + "min"} · ${c.likes}人推荐\n\n`; });
    r += `🔧 工具使用：${toolCount.map(([t, n]) => `${t}(${n}次)`).join(" / ")}\n\n`;
    r += `📌 趋势：${stats.catCounts[0] ? `${stats.catCounts[0][0]}场景最活跃` : ""}，${thisWeek.length > 3 ? "团队AI实践持续增长" : "建议推动更多场景试点"}`;
    return r;
  };

  const [reportText, setReportText] = useState("");

  const tabStyle = (t) => ({ padding: "8px 18px", borderRadius: 8, border: "none", background: tab === t ? "rgba(99,102,241,0.15)" : "transparent", color: tab === t ? "#818cf8" : "#555", fontSize: 13, fontWeight: tab === t ? 600 : 400, cursor: "pointer", transition: "all 0.2s", whiteSpace: "nowrap" });
  const inputStyle = { background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 8, padding: "9px 12px", color: "#ccc", fontSize: 13, outline: "none", width: "100%", transition: "border-color 0.2s" };
  const chipStyle = (active) => ({ padding: "5px 12px", borderRadius: 6, border: "1px solid", borderColor: active ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.06)", background: active ? "rgba(99,102,241,0.1)" : "transparent", color: active ? "#818cf8" : "#555", fontSize: 12, cursor: "pointer", transition: "all 0.15s", whiteSpace: "nowrap" });

  return (
    <div style={{ minHeight: "100vh", background: "#08080d", color: "#e8e8f0", fontFamily: "'Noto Sans SC', -apple-system, system-ui, sans-serif" }}>
      <div style={{ maxWidth: 1000, margin: "0 auto", padding: "36px 24px 80px" }}>

        <div style={{ marginBottom: 36 }}>
          <div style={{ fontSize: 10, letterSpacing: 4, color: "#4f46e5", marginBottom: 10, fontWeight: 600, textTransform: "uppercase" }}>Design Team AI Practice Hub</div>
          <h1 style={{ fontSize: 30, fontWeight: 800, margin: 0, color: "#e8e8f0" }}>AI 实践看板</h1>
          <p style={{ fontSize: 13, color: "#555", marginTop: 6, lineHeight: 1.6 }}>每一次AI实践都值得被记录 · 你的Prompt可能帮到下一个人</p>
        </div>

        <div style={{ display: "flex", gap: 4, marginBottom: 28, background: "rgba(255,255,255,0.015)", padding: 4, borderRadius: 10, width: "fit-content", border: "1px solid rgba(255,255,255,0.04)" }}>
          {[["browse", "案例库"], ["dashboard", "数据看板"], ["submit", "提交案例"], ["report", "周报"]].map(([k, v]) => (
            <button key={k} style={tabStyle(k)} onClick={() => { setTab(k); if (k === "report") setReportText(generateReport()); }}>{v}</button>
          ))}
        </div>

        {tab === "browse" && (
          <div>
            <div style={{ display: "flex", gap: 8, marginBottom: 18, flexWrap: "wrap", alignItems: "center" }}>
              <input style={{ ...inputStyle, maxWidth: 220 }} placeholder="搜索..." value={search} onChange={e => setSearch(e.target.value)} onFocus={e => e.target.style.borderColor = "rgba(99,102,241,0.3)"} onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.07)"} />
              <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                {["全部", ...CATEGORIES.slice(0, 6)].map(c => (
                  <button key={c} style={chipStyle(filterCat === c)} onClick={() => setFilterCat(c)}>{c}</button>
                ))}
              </div>
            </div>
            <div style={{ display: "flex", gap: 4, marginBottom: 20, flexWrap: "wrap", alignItems: "center" }}>
              <span style={{ fontSize: 11, color: "#444", marginRight: 4 }}>工具:</span>
              {["全部", ...TOOLS.slice(0, 8)].map(t => (
                <button key={t} style={chipStyle(filterTool === t)} onClick={() => setFilterTool(t)}>{t}</button>
              ))}
              <span style={{ fontSize: 11, color: "#333", marginLeft: "auto" }}>{filtered.length} 条</span>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {filtered.map(c => <CaseCard key={c.id} item={c} onLike={handleLike} />)}
              {filtered.length === 0 && <div style={{ textAlign: "center", color: "#444", padding: 48, fontSize: 13 }}>暂无匹配案例，换个筛选条件试试</div>}
            </div>
          </div>
        )}

        {tab === "dashboard" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
              <StatCard label="案例总数" value={stats.total} sub="持续增长中" accent="#818cf8" />
              <StatCard label="本周新增" value={stats.thisWeek} sub="最近7天" accent="#34d399" />
              <StatCard label="累计节省" value={`${stats.totalHours}h`} sub={`≈ ${Math.round(stats.totalHours / 8)} 人天`} accent="#fb923c" />
              <StatCard label="参与设计师" value={stats.authors} sub={`/ 100+ 团队`} accent="#f472b6" />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 14, padding: 22 }}>
                <div style={{ fontSize: 10, color: "#555", marginBottom: 14, letterSpacing: 1, textTransform: "uppercase", fontWeight: 600 }}>工具热度排行</div>
                {stats.toolCounts.slice(0, 5).map(([tool, count], i) => (
                  <div key={tool} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                    <span style={{ fontSize: 11, color: "#444", width: 16 }}>{i + 1}</span>
                    <span style={{ fontSize: 13, color: "#bbb", flex: 1 }}>{tool}</span>
                    <div style={{ width: 100, height: 6, background: "rgba(255,255,255,0.04)", borderRadius: 3, overflow: "hidden" }}>
                      <div style={{ width: `${(count / stats.toolCounts[0][1]) * 100}%`, height: "100%", background: "linear-gradient(90deg, #4f46e5, #818cf8)", borderRadius: 3 }} />
                    </div>
                    <span style={{ fontSize: 11, color: "#555", width: 24, textAlign: "right" }}>{count}</span>
                  </div>
                ))}
              </div>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 14, padding: 22 }}>
                <div style={{ fontSize: 10, color: "#555", marginBottom: 14, letterSpacing: 1, textTransform: "uppercase", fontWeight: 600 }}>场景分布</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {stats.catCounts.map(([cat, count]) => (
                    <div key={cat} style={{ background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.12)", borderRadius: 8, padding: "8px 14px" }}>
                      <span style={{ fontSize: 13, color: "#999" }}>{cat}</span>
                      <span style={{ fontSize: 15, color: "#818cf8", fontWeight: 700, marginLeft: 8 }}>{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {stats.topCase && (
              <div style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.06), rgba(244,114,182,0.04))", border: "1px solid rgba(99,102,241,0.12)", borderRadius: 14, padding: 22 }}>
                <div style={{ fontSize: 10, color: "#555", marginBottom: 10, letterSpacing: 1, textTransform: "uppercase", fontWeight: 600 }}>🏆 最受欢迎案例</div>
                <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 4 }}>{stats.topCase.title}</div>
                <div style={{ fontSize: 13, color: "#777" }}>by {stats.topCase.author} · {stats.topCase.likes} 人推荐 · 省时 {stats.topCase.timeSaved >= 60 ? Math.round(stats.topCase.timeSaved / 60) + "h" : stats.topCase.timeSaved + "min"}</div>
              </div>
            )}
          </div>
        )}

        {tab === "submit" && (
          <div style={{ maxWidth: 680 }}>
            {submitted ? (
              <div style={{ textAlign: "center", padding: 60 }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>🎉</div>
                <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>提交成功</div>
                <div style={{ fontSize: 13, color: "#666" }}>感谢分享，正在跳转...</div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                <div style={{ fontSize: 13, color: "#777", lineHeight: 1.7, background: "rgba(99,102,241,0.04)", border: "1px solid rgba(99,102,241,0.08)", borderRadius: 12, padding: "14px 18px" }}>
                  记录你的AI实践。不需要完美，真实就好。贴上截图和Prompt，帮到下一个人。
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                  <div>
                    <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>你是谁</label>
                    <input style={inputStyle} value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} placeholder="花名" />
                  </div>
                  <div>
                    <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>省了多久（分钟）</label>
                    <input style={inputStyle} type="number" value={form.timeSaved} onChange={e => setForm({ ...form, timeSaved: e.target.value })} placeholder="估算" />
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
                  <div>
                    <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>场景</label>
                    <select style={inputStyle} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select>
                  </div>
                  <div>
                    <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>工具</label>
                    <select style={inputStyle} value={form.tool} onChange={e => setForm({ ...form, tool: e.target.value })}>{TOOLS.map(t => <option key={t}>{t}</option>)}</select>
                  </div>
                  <div>
                    <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>效果</label>
                    <select style={inputStyle} value={form.rating} onChange={e => setForm({ ...form, rating: e.target.value })}>{RATINGS.map(r => <option key={r}>{r}</option>)}</select>
                  </div>
                </div>

                <div>
                  <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>一句话说清楚</label>
                  <input style={inputStyle} value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="例：用即梦批量生成8张会员Banner" />
                </div>

                <div>
                  <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>详细说说</label>
                  <textarea style={{ ...inputStyle, minHeight: 80, resize: "vertical" }} value={form.desc} onChange={e => setForm({ ...form, desc: e.target.value })} placeholder="怎么做的、效果如何、踩了什么坑..." />
                </div>

                <div>
                  <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>上传图片/视频（效果图、截图、录屏、Before/After对比）</label>
                  <ImageUploader images={uploadedImages} onChange={setUploadedImages} />
                  {uploadedImages.length >= 2 && (
                    <label style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 10, cursor: "pointer", fontSize: 12, color: "#777" }}>
                      <input type="checkbox" checked={form.beforeAfter} onChange={e => setForm({ ...form, beforeAfter: e.target.checked })} style={{ accentColor: "#818cf8" }} />
                      前两张图作为 Before/After 对比展示
                    </label>
                  )}
                </div>

                <div>
                  <label style={{ fontSize: 11, color: "#555", marginBottom: 4, display: "block" }}>Prompt / 操作步骤（可选）</label>
                  <textarea style={{ ...inputStyle, minHeight: 72, resize: "vertical", fontFamily: "'JetBrains Mono', monospace" }} value={form.prompt} onChange={e => setForm({ ...form, prompt: e.target.value })} placeholder="贴Prompt或者写操作步骤，方便其他人复用" />
                </div>

                <button onClick={handleSubmit} disabled={!form.title || !form.desc || !form.author} style={{ background: form.title && form.desc && form.author ? "#4f46e5" : "rgba(255,255,255,0.04)", border: "none", borderRadius: 10, padding: "13px 0", color: form.title && form.desc && form.author ? "#fff" : "#444", fontSize: 14, fontWeight: 600, cursor: form.title && form.desc && form.author ? "pointer" : "not-allowed", transition: "all 0.2s" }}>
                  提交案例
                </button>
              </div>
            )}
          </div>
        )}

        {tab === "report" && (
          <div style={{ maxWidth: 680 }}>
            <div style={{ fontSize: 13, color: "#666", marginBottom: 18, lineHeight: 1.7 }}>
              基于最近7天数据自动生成，直接复制发给领导。
            </div>
            <div style={{ background: "rgba(0,0,0,0.25)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 12, padding: 22 }}>
              <pre style={{ fontSize: 13, color: "#bbb", lineHeight: 1.9, whiteSpace: "pre-wrap", margin: 0, fontFamily: "'Noto Sans SC', sans-serif" }}>{reportText}</pre>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button onClick={() => navigator.clipboard?.writeText(reportText)} style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 8, padding: "10px 22px", color: "#818cf8", fontSize: 13, fontWeight: 500, cursor: "pointer" }}>
                复制周报
              </button>
              <button onClick={() => setReportText(generateReport())} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 8, padding: "10px 22px", color: "#777", fontSize: 13, cursor: "pointer" }}>
                重新生成
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
