import { useState, useMemo } from "react";

const CATEGORIES = ["需求转译", "UI生成", "视觉探索", "动效生成", "走查验收", "代码交付", "素材批量", "竞品分析", "用研提效", "其他"];
const TOOLS = ["Claude", "Gemini Pro", "Figma Make", "即梦", "Midjourney", "Cursor", "nano banana", "Lovart", "Liblib", "seedance", "OpenClaw", "其他"];
const RATINGS = ["🔥 强烈推荐", "👍 有效果", "🤔 一般", "👎 不推荐"];

const DEMO_DATA = [
  { id: 1, author: "小林", date: "2026-03-21", category: "需求转译", tool: "Claude", title: "PRD自动提取交互要点", desc: "把12页PRD丢给Claude，10分钟出交互要点清单，以前要读1小时", prompt: "你是一名资深交互设计师，请阅读以下PRD文档，提取所有涉及用户交互的功能点...", timeSaved: 50, rating: "🔥 强烈推荐", likes: 12 },
  { id: 2, author: "阿杰", date: "2026-03-20", category: "素材批量", tool: "即梦", title: "会员活动Banner批量生成", desc: "用即梦+固定Prompt模板，一次生成8张不同风格的会员活动Banner，从2天缩到2小时", prompt: "设计一张网易云音乐会员活动Banner，风格：赛博朋克，主色调：黑金...", timeSaved: 720, rating: "🔥 强烈推荐", likes: 24 },
  { id: 3, author: "Mia", date: "2026-03-19", category: "UI生成", tool: "Figma Make", title: "播放器改版初稿AI生成", desc: "用Figma Make基于设计系统直接出播放器改版初稿，虽然还需要大改但省了探索时间", prompt: "基于现有播放器布局，生成3种不同风格的改版方案...", timeSaved: 180, rating: "👍 有效果", likes: 8 },
  { id: 4, author: "你", date: "2026-03-22", category: "需求转译", tool: "Gemini Pro", title: "竞品功能对比表自动生成", desc: "把5个竞品截图丢给Gemini Pro，自动生成功能对比矩阵表，准确率约85%", prompt: "分析以下5个音乐App的会员权益页面截图，生成对比表格...", timeSaved: 120, rating: "👍 有效果", likes: 6 },
  { id: 5, author: "小周", date: "2026-03-18", category: "动效生成", tool: "seedance", title: "播放器转场动效方案", desc: "用seedance2.0生成播放器页面切换的过渡动效方案，直接输出Lottie可用", prompt: "生成一个音乐播放器从列表页到播放页的转场动效...", timeSaved: 240, rating: "🔥 强烈推荐", likes: 15 },
];

function StatCard({ label, value, sub }) {
  return (
    <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: "18px 20px", minWidth: 0 }}>
      <div style={{ fontSize: 12, color: "#888", marginBottom: 6, letterSpacing: 0.5 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color: "#e8e8f0", lineHeight: 1.2 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: "#666", marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function CaseCard({ item, onLike }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20, transition: "border-color 0.2s", cursor: "pointer" }} onClick={() => setExpanded(!expanded)} onMouseEnter={e => e.currentTarget.style.borderColor = "rgba(99,102,241,0.4)"} onMouseLeave={e => e.currentTarget.style.borderColor = "rgba(255,255,255,0.06)"}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div>
          <span style={{ fontSize: 11, background: "rgba(99,102,241,0.15)", color: "#818cf8", padding: "3px 8px", borderRadius: 4, marginRight: 8 }}>{item.category}</span>
          <span style={{ fontSize: 11, background: "rgba(52,211,153,0.12)", color: "#34d399", padding: "3px 8px", borderRadius: 4 }}>{item.tool}</span>
        </div>
        <span style={{ fontSize: 11, color: "#555" }}>{item.date}</span>
      </div>
      <div style={{ fontSize: 15, fontWeight: 600, color: "#e8e8f0", marginBottom: 6 }}>{item.title}</div>
      <div style={{ fontSize: 13, color: "#888", lineHeight: 1.6, marginBottom: 10 }}>{item.desc}</div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <span style={{ fontSize: 12, color: "#666" }}>by {item.author}</span>
          <span style={{ fontSize: 12, color: "#fb923c" }}>省 {item.timeSaved >= 60 ? `${Math.round(item.timeSaved / 60)}h` : `${item.timeSaved}min`}</span>
          <span style={{ fontSize: 12 }}>{item.rating}</span>
        </div>
        <button onClick={e => { e.stopPropagation(); onLike(item.id); }} style={{ background: "none", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 6, padding: "4px 10px", color: "#888", fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}>
          <span>👍</span> {item.likes}
        </button>
      </div>
      {expanded && (
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ fontSize: 11, color: "#666", marginBottom: 6, letterSpacing: 0.5 }}>PROMPT</div>
          <div style={{ fontSize: 12, color: "#aaa", background: "rgba(0,0,0,0.3)", borderRadius: 8, padding: 12, lineHeight: 1.6, fontFamily: "monospace", whiteSpace: "pre-wrap", wordBreak: "break-all" }}>{item.prompt}</div>
          <button onClick={e => { e.stopPropagation(); navigator.clipboard?.writeText(item.prompt); }} style={{ marginTop: 8, background: "rgba(99,102,241,0.15)", border: "none", borderRadius: 6, padding: "6px 14px", color: "#818cf8", fontSize: 12, cursor: "pointer" }}>
            复制 Prompt
          </button>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("browse");
  const [cases, setCases] = useState(DEMO_DATA);
  const [filterCat, setFilterCat] = useState("全部");
  const [filterTool, setFilterTool] = useState("全部");
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ author: "", category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0] });
  const [submitted, setSubmitted] = useState(false);

  const filtered = useMemo(() => {
    return cases.filter(c => {
      if (filterCat !== "全部" && c.category !== filterCat) return false;
      if (filterTool !== "全部" && c.tool !== filterTool) return false;
      if (search && !c.title.includes(search) && !c.desc.includes(search) && !c.author.includes(search)) return false;
      return true;
    }).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [cases, filterCat, filterTool, search]);

  const stats = useMemo(() => {
    const thisWeek = cases.filter(c => { const d = new Date(c.date); const now = new Date(); const diff = (now - d) / (1000 * 60 * 60 * 24); return diff <= 7; });
    const totalTime = cases.reduce((s, c) => s + c.timeSaved, 0);
    const authors = new Set(cases.map(c => c.author));
    const topCase = [...cases].sort((a, b) => b.likes - a.likes)[0];
    const topTool = Object.entries(cases.reduce((acc, c) => { acc[c.tool] = (acc[c.tool] || 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1])[0];
    return { total: cases.length, thisWeek: thisWeek.length, totalHours: Math.round(totalTime / 60), authors: authors.size, topCase, topTool };
  }, [cases]);

  const handleSubmit = () => {
    if (!form.title || !form.desc || !form.author) return;
    const newCase = { ...form, id: Date.now(), date: new Date().toISOString().slice(0, 10), timeSaved: parseInt(form.timeSaved) || 0, likes: 0 };
    setCases(prev => [newCase, ...prev]);
    setForm({ author: "", category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0] });
    setSubmitted(true);
    setTimeout(() => { setSubmitted(false); setTab("browse"); }, 1500);
  };

  const handleLike = (id) => setCases(prev => prev.map(c => c.id === id ? { ...c, likes: c.likes + 1 } : c));

  const generateReport = () => {
    const thisWeek = cases.filter(c => { const d = new Date(c.date); const now = new Date(); return (now - d) / (1000 * 60 * 60 * 24) <= 7; });
    const totalMin = thisWeek.reduce((s, c) => s + c.timeSaved, 0);
    const authors = [...new Set(thisWeek.map(c => c.author))];
    const top = [...thisWeek].sort((a, b) => b.likes - a.likes).slice(0, 3);
    const toolCount = Object.entries(thisWeek.reduce((acc, c) => { acc[c.tool] = (acc[c.tool] || 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]);
    
    let report = `📊 设计团队 AI 实践周报\n${"═".repeat(30)}\n\n`;
    report += `📅 统计周期：最近7天\n👥 参与人数：${authors.length}人（${authors.join("、")}）\n📝 案例总数：${thisWeek.length}条\n⏱️ 累计节省：${Math.round(totalMin / 60)}小时${totalMin % 60}分钟\n\n`;
    report += `🏆 Top 案例：\n`;
    top.forEach((c, i) => { report += `${i + 1}. 「${c.title}」by ${c.author} — 省时${c.timeSaved >= 60 ? Math.round(c.timeSaved / 60) + "h" : c.timeSaved + "min"}，${c.likes}人点赞\n`; });
    report += `\n🔧 最常用工具：${toolCount.map(([t, n]) => `${t}(${n}次)`).join("、")}\n`;
    report += `\n📌 下周关注：持续收集闭环交付场景案例，推动AI辅助流程标准化。`;
    return report;
  };

  const [reportText, setReportText] = useState("");

  const tabStyle = (t) => ({ padding: "8px 20px", borderRadius: 8, border: "none", background: tab === t ? "rgba(99,102,241,0.2)" : "transparent", color: tab === t ? "#818cf8" : "#666", fontSize: 13, fontWeight: 500, cursor: "pointer", transition: "all 0.2s" });
  const selectStyle = { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "8px 12px", color: "#ccc", fontSize: 13, outline: "none", minWidth: 100 };
  const inputStyle = { ...selectStyle, width: "100%" };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", color: "#e8e8f0", fontFamily: "'Noto Sans SC', -apple-system, sans-serif" }}>
      <div style={{ maxWidth: 960, margin: "0 auto", padding: "32px 20px 80px" }}>
        
        {/* Header */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 11, letterSpacing: 3, color: "#818cf8", marginBottom: 8, fontWeight: 500 }}>AI PRACTICE HUB</div>
          <h1 style={{ fontSize: 28, fontWeight: 800, margin: 0, lineHeight: 1.3, background: "linear-gradient(135deg, #e8e8f0 30%, #818cf8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            设计团队 AI 实践看板
          </h1>
          <p style={{ fontSize: 13, color: "#666", marginTop: 6 }}>记录每一次AI实践，让经验流转起来</p>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 28, background: "rgba(255,255,255,0.02)", padding: 4, borderRadius: 10, width: "fit-content" }}>
          <button style={tabStyle("browse")} onClick={() => setTab("browse")}>案例库</button>
          <button style={tabStyle("dashboard")} onClick={() => setTab("dashboard")}>数据看板</button>
          <button style={tabStyle("submit")} onClick={() => setTab("submit")}>提交案例</button>
          <button style={tabStyle("report")} onClick={() => { setTab("report"); setReportText(generateReport()); }}>周报生成</button>
        </div>

        {/* Browse */}
        {tab === "browse" && (
          <div>
            <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
              <input style={{ ...inputStyle, maxWidth: 240 }} placeholder="搜索案例..." value={search} onChange={e => setSearch(e.target.value)} />
              <select style={selectStyle} value={filterCat} onChange={e => setFilterCat(e.target.value)}>
                <option>全部</option>
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
              <select style={selectStyle} value={filterTool} onChange={e => setFilterTool(e.target.value)}>
                <option>全部</option>
                {TOOLS.map(t => <option key={t}>{t}</option>)}
              </select>
              <span style={{ fontSize: 12, color: "#555", alignSelf: "center" }}>{filtered.length} 条案例</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {filtered.map(c => <CaseCard key={c.id} item={c} onLike={handleLike} />)}
              {filtered.length === 0 && <div style={{ textAlign: "center", color: "#555", padding: 40, fontSize: 13 }}>暂无匹配案例</div>}
            </div>
          </div>
        )}

        {/* Dashboard */}
        {tab === "dashboard" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 28 }}>
              <StatCard label="案例总数" value={stats.total} sub="持续增长中" />
              <StatCard label="本周新增" value={stats.thisWeek} sub="最近7天" />
              <StatCard label="累计节省" value={`${stats.totalHours}h`} sub="团队总计" />
              <StatCard label="参与人数" value={stats.authors} sub="设计师" />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 28 }}>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
                <div style={{ fontSize: 12, color: "#888", marginBottom: 14, letterSpacing: 0.5 }}>TOP 案例</div>
                {stats.topCase && (
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>{stats.topCase.title}</div>
                    <div style={{ fontSize: 12, color: "#666" }}>by {stats.topCase.author} · {stats.topCase.likes} 人推荐</div>
                  </div>
                )}
              </div>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
                <div style={{ fontSize: 12, color: "#888", marginBottom: 14, letterSpacing: 0.5 }}>最常用工具</div>
                {stats.topTool && (
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>{stats.topTool[0]}</div>
                    <div style={{ fontSize: 12, color: "#666" }}>被使用 {stats.topTool[1]} 次</div>
                  </div>
                )}
              </div>
            </div>

            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 12, color: "#888", marginBottom: 14, letterSpacing: 0.5 }}>场景分布</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {Object.entries(cases.reduce((acc, c) => { acc[c.category] = (acc[c.category] || 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]).map(([cat, count]) => (
                  <div key={cat} style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 8, padding: "8px 14px", fontSize: 13 }}>
                    <span style={{ color: "#818cf8", fontWeight: 600 }}>{cat}</span>
                    <span style={{ color: "#666", marginLeft: 8 }}>{count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Submit */}
        {tab === "submit" && (
          <div style={{ maxWidth: 640 }}>
            {submitted ? (
              <div style={{ textAlign: "center", padding: 60 }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>🎉</div>
                <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>提交成功！</div>
                <div style={{ fontSize: 13, color: "#666" }}>感谢你的分享，正在跳转到案例库...</div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div style={{ fontSize: 13, color: "#888", lineHeight: 1.7, background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.12)", borderRadius: 10, padding: 16, marginBottom: 4 }}>
                  记录你的AI实践：用了什么工具、做了什么事、效果怎样。不需要完美，真实就好。你的Prompt可能帮到下一个遇到同样问题的人。
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <div>
                    <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>你的名字</label>
                    <input style={inputStyle} value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} placeholder="花名或真名" />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>节省时间（分钟）</label>
                    <input style={inputStyle} type="number" value={form.timeSaved} onChange={e => setForm({ ...form, timeSaved: e.target.value })} placeholder="估算即可" />
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                  <div>
                    <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>场景分类</label>
                    <select style={inputStyle} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                      {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>使用工具</label>
                    <select style={inputStyle} value={form.tool} onChange={e => setForm({ ...form, tool: e.target.value })}>
                      {TOOLS.map(t => <option key={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>效果评级</label>
                    <select style={inputStyle} value={form.rating} onChange={e => setForm({ ...form, rating: e.target.value })}>
                      {RATINGS.map(r => <option key={r}>{r}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>标题（一句话说清楚你做了什么）</label>
                  <input style={inputStyle} value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="例：用Claude自动提取PRD交互要点" />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>详细描述</label>
                  <textarea style={{ ...inputStyle, minHeight: 80, resize: "vertical" }} value={form.desc} onChange={e => setForm({ ...form, desc: e.target.value })} placeholder="具体怎么做的、效果如何、有什么坑..." />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "#666", marginBottom: 4, display: "block" }}>Prompt（可选，但强烈建议贴出来）</label>
                  <textarea style={{ ...inputStyle, minHeight: 80, resize: "vertical", fontFamily: "monospace" }} value={form.prompt} onChange={e => setForm({ ...form, prompt: e.target.value })} placeholder="贴出你使用的核心Prompt，方便其他人直接复用" />
                </div>
                <button onClick={handleSubmit} disabled={!form.title || !form.desc || !form.author} style={{ background: form.title && form.desc && form.author ? "rgba(99,102,241,0.8)" : "rgba(255,255,255,0.05)", border: "none", borderRadius: 10, padding: "12px 0", color: form.title && form.desc && form.author ? "#fff" : "#555", fontSize: 14, fontWeight: 600, cursor: form.title && form.desc && form.author ? "pointer" : "not-allowed", transition: "all 0.2s" }}>
                  提交案例
                </button>
              </div>
            )}
          </div>
        )}

        {/* Report */}
        {tab === "report" && (
          <div style={{ maxWidth: 640 }}>
            <div style={{ fontSize: 13, color: "#888", marginBottom: 16, lineHeight: 1.7 }}>
              基于最近7天的案例数据自动生成周报，可直接复制发给领导。
            </div>
            <div style={{ background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
              <pre style={{ fontSize: 13, color: "#ccc", lineHeight: 1.8, whiteSpace: "pre-wrap", margin: 0, fontFamily: "'Noto Sans SC', sans-serif" }}>{reportText}</pre>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button onClick={() => navigator.clipboard?.writeText(reportText)} style={{ background: "rgba(99,102,241,0.2)", border: "none", borderRadius: 8, padding: "10px 20px", color: "#818cf8", fontSize: 13, fontWeight: 500, cursor: "pointer" }}>
                复制周报
              </button>
              <button onClick={() => setReportText(generateReport())} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "10px 20px", color: "#888", fontSize: 13, cursor: "pointer" }}>
                重新生成
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
