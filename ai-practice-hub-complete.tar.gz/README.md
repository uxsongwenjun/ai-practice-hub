# AI 实践看板

设计团队 AI 实践平台 - 用于提交和浏览 AI 使用案例

## 🎯 项目概述

一个为设计团队构建的 AI 使用案例管理平台，支持案例提交、浏览、点赞和统计分析。

**核心功能：**
- 🔐 花名 + 暗号认证系统
- 📝 案例提交与编辑（包含 Before/After 对比）
- 📊 数据看板（统计和趋势分析）
- ⏱️ 智能时间格式化（分钟/小时/天）
- ❤️ 点赞和收藏
- 🔍 搜索和多维筛选
- 📦 Docker 容器化部署

## 🛠️ 技术栈

- **框架**：Next.js 16 + React 19
- **数据库**：SQLite (better-sqlite3)
- **样式**：Inline CSS + Tailwind CSS
- **部署**：Docker + Node.js 20

## 📦 快速开始

### 本地开发

```bash
# 安装依赖
npm install

# 运行开发服务器
npm run dev

# 访问 http://localhost:3000
```

### Docker 部署

```bash
# 构建镜像
docker build -t ai-practice-hub:latest .

# 运行容器
docker run -p 3000:3000 -v $(pwd)/data:/app/data ai-practice-hub:latest

# 或指定其他端口
docker run -p 8080:3000 -v $(pwd)/data:/app/data ai-practice-hub:latest
```

## 📂 项目结构

```
ai-practice-hub/
├── app/
│   ├── PracticeHub.jsx          # 主应用组件
│   ├── api/
│   │   └── cases/               # API 路由
│   │       ├── route.js         # 列表、创建
│   │       └── [id]/
│   │           ├── route.js     # 查询、编辑、删除
│   │           └── like/route.js # 点赞
│   └── page.tsx
├── lib/
│   └── db.js                    # 数据库初始化
├── public/
│   └── demo-images/             # 演示图片
├── Dockerfile                   # Docker 配置
├── package.json
└── README.md
```

## 🔑 认证信息

**测试账户：**
- 花名：任意输入（如 "小王"）
- 暗号：`163`

## 📊 API 文档

### 获取所有案例
```bash
GET /api/cases
```

### 创建案例
```bash
POST /api/cases
Content-Type: application/json

{
  "author": "李飞",
  "date": "2026-03-24",
  "category": "素材批量",
  "tool": "即梦",
  "title": "艺人 Banner 批量设计",
  "desc": "...",
  "timeSaved": 480
}
```

### 编辑案例
```bash
PUT /api/cases/:id
```

### 删除案例
```bash
DELETE /api/cases/:id
```

### 点赞案例
```bash
POST /api/cases/:id/like
```

## 🚀 部署建议

### 生产构建
```bash
npm run build
npm start
```

### 环境变量
创建 `.env.local` 文件（可选）：
```
DATABASE_PATH=/app/data/practice.db
NODE_ENV=production
```

## 📝 功能清单

- [x] 案例库浏览和搜索
- [x] 多维筛选（场景、工具、排序）
- [x] 案例提交表单
- [x] Before/After 对比
- [x] 数据看板统计
- [x] 周报生成
- [x] 编辑和删除功能
- [x] 两段式删除确认
- [x] 点赞系统
- [x] Docker 容器化
- [x] 时间格式优化

## 🔐 安全说明

- 认证采用简单的花名 + 暗号机制（第一阶段）
- 生产环境建议对接企业 SSO (OAuth2)
- 数据库采用 SQLite，生产环境建议迁移到 PostgreSQL
- 所有 API 请求需要验证用户身份

## 📈 后续计划

- [ ] 企业 SSO 集成
- [ ] PostgreSQL 数据库迁移
- [ ] 高级权限管理
- [ ] 数据导出功能
- [ ] 用户头像和个人页面
- [ ] 评论和讨论功能
- [ ] 移动端适配

---

**最后更新：2026-03-24**
