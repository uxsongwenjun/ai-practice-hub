"use client";
// AI 实践看板 — Perplexity 深色风格
// 设计规范：深色背景 / 细边框 / 青绿主色 #20B2AA / 极简筛选（下拉代替芯片堆叠）
import { useState, useMemo, useRef, useEffect, useCallback, memo } from "react";

// ─── 时间格式化函数 ────────────────────────────────────────────────
const formatTime = (minutes) => {
  if (minutes >= 1440) { // 24小时 = 1440分钟
    const days = Math.round(minutes / 1440);
    return `${days}天`;
  } else if (minutes >= 60) {
    const hours = Math.round(minutes / 60);
    return `${hours}h`;
  } else {
    return `${minutes}min`;
  }
};

// ─── 设计 Token（深色模式）────────────────────────────────────────
const T = {
  bg:          "#1C1C1C",   // 页面背景
  bgCard:      "#242424",   // 卡片背景
  bgSub:       "#2A2A2A",   // 输入框、代码块背景
  bgHover:     "#303030",   // hover 态
  border:      "#333333",   // 通用边框
  borderFocus: "#20B2AA",
  text:        "#EDEDEC",   // 主文字
  textSub:     "#8F8F8F",   // 次级文字
  textMute:    "#5A5A5A",   // 弱化文字
  accent:      "#20B2AA",   // Perplexity teal
  accentBg:    "#1A3333",   // teal 低饱和背景
  orange:      "#F59E0B",
  green:       "#10B981",
  purple:      "#8B5CF6",
  radius:      "10px",
  radiusSm:    "6px",
  shadow:      "0 1px 3px rgba(0,0,0,0.3), 0 1px 2px rgba(0,0,0,0.2)",
  shadowHover: "0 4px 16px rgba(0,0,0,0.4)",
};

// ─── 常量 ─────────────────────────────────────────────────────────
const CATEGORIES = ["需求转译", "UI生成", "视觉探索", "动效生成", "走查验收", "代码交付", "素材批量", "竞品分析", "用研提效", "其他"];
const TOOLS = ["Claude", "Gemini Pro", "Figma Make", "即梦", "Midjourney", "Cursor", "nano banana", "Lovart", "Liblib", "seedance", "OpenClaw", "Stitch", "Tapnow", "其他"];
const RATINGS = ["🔥 强烈推荐", "👍 有效果", "🤔 一般", "👎 不推荐"];

// 省时映射：音乐感知单位 → 分钟数
// 对音乐人来说「一首歌」比「3.5分钟」直观 100 倍
const TIME_OPTIONS = [
  { label: "一首歌",   emoji: "🎵", min: 4,    desc: "≈ 4 min" },
  { label: "一张 EP",  emoji: "💿", min: 20,   desc: "≈ 20 min" },
  { label: "一张专辑", emoji: "📀", min: 45,   desc: "≈ 45 min" },
  { label: "一场 Live",emoji: "🎤", min: 120,  desc: "≈ 2 h" },
  { label: "一天排练", emoji: "🎸", min: 480,  desc: "≈ 8 h" },
  { label: "一次巡演", emoji: "🚌", min: 1440, desc: "≈ 数天" },
];

// 每个分类对应的颜色
const CAT_COLOR = {
  "需求转译": "#8B5CF6", "UI生成": "#20B2AA",  "视觉探索": "#EC4899",
  "动效生成": "#F59E0B", "走查验收": "#10B981", "代码交付": "#3B82F6",
  "素材批量": "#F97316", "竞品分析": "#6366F1", "用研提效": "#14B8A6", "其他": "#9CA3AF",
};

// ─── Toast 通知 ───────────────────────────────────────────────────
function Toast({ msg, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 2200); return () => clearTimeout(t); }, [onClose]);
  return (
    <div style={{ position: "fixed", bottom: 28, left: "50%", transform: "translateX(-50%)", background: T.text, color: "#000", borderRadius: 8, padding: "10px 20px", fontSize: 13, fontWeight: 500, zIndex: 9999, boxShadow: "0 8px 24px rgba(0,0,0,0.15)", display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ color: T.accent }}>✓</span> {msg}
    </div>
  );
}

// ─── 统计卡片 ─────────────────────────────────────────────────────
function StatCard({ label, value, sub, accent, icon }) {
  return (
    <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: "20px 22px", boxShadow: T.shadow }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <span style={{ fontSize: 16 }}>{icon}</span>
        <span style={{ fontSize: 11, color: T.textMute, fontWeight: 500, letterSpacing: 0.3 }}>{label}</span>
      </div>
      <div style={{ fontSize: 30, fontWeight: 700, color: accent || T.text, lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: T.textMute, marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

// ─── 卡片类型系统 ─────────────────────────────────────────────────
// compare : Before/After 拖拽对比（视觉改造类）
// batch   : 1入N出批量生成（素材批量类）
// flow    : 多步骤工作流（Agent/自动化类）
// text    : 纯文字分析（研究/策略类，无视觉产出）
// 自动判断：有 beforeAfter→compare, steps→flow, images>1→batch, else→text

// ── Before/After 拖拽滑块 ──────────────────────────────────────────
function BeforeAfterSlider({ before, after, beforeLabel, afterLabel, height = 180 }) {
  const [pos, setPos] = useState(50);
  const [dragging, setDragging] = useState(false);
  const ref = useRef(null);

  const move = useCallback((clientX) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    setPos(Math.max(5, Math.min(95, ((clientX - r.left) / r.width) * 100)));
  }, []);

  const onDown  = (e) => { e.preventDefault(); setDragging(true); };
  const onMove  = useCallback((e) => { if (dragging) move(e.clientX); }, [dragging, move]);
  const onUp    = useCallback(() => setDragging(false), []);

  useEffect(() => {
    if (dragging) { window.addEventListener("mousemove", onMove); window.addEventListener("mouseup", onUp); }
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
  }, [dragging, onMove, onUp]);

  return (
    <div ref={ref} style={{ position: "relative", height, overflow: "hidden", userSelect: "none", cursor: dragging ? "col-resize" : "ew-resize" }}
      onMouseDown={onDown} onTouchMove={e => { e.preventDefault(); move(e.touches[0].clientX); }} onTouchEnd={onUp}>
      {/* AFTER 底层 */}
      <img src={after} alt="after" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
      {/* BEFORE 通过 clip-path 裁剪 */}
      <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <img src={before} alt="before" style={{ width: "100%", height: "100%", objectFit: "cover", filter: "saturate(0.2) brightness(0.8)" }} />
      </div>
      {/* 分割线 + 手柄 */}
      <div style={{ position: "absolute", top: 0, bottom: 0, left: `${pos}%`, transform: "translateX(-50%)", width: 2, background: "rgba(255,255,255,0.85)", zIndex: 10, pointerEvents: "none" }}>
        <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 28, height: 28, borderRadius: "50%", background: "#fff", boxShadow: "0 2px 8px rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: "#333", fontWeight: 700 }}>⇔</div>
      </div>
      {/* 标签 */}
      <div style={{ position: "absolute", top: 8, left: 8, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", borderRadius: 4, padding: "2px 8px", fontSize: 9, color: "#fca5a5", fontWeight: 700, zIndex: 11 }}>BEFORE · {beforeLabel || "改造前"}</div>
      <div style={{ position: "absolute", top: 8, right: 8, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", borderRadius: 4, padding: "2px 8px", fontSize: 9, color: "#6ee7b7", fontWeight: 700, zIndex: 11 }}>AFTER · {afterLabel || "改造后"}</div>
      {!dragging && <div style={{ position: "absolute", bottom: 8, left: "50%", transform: "translateX(-50%)", background: "rgba(0,0,0,0.45)", backdropFilter: "blur(4px)", borderRadius: 20, padding: "2px 10px", fontSize: 9, color: "rgba(255,255,255,0.65)", zIndex: 11, whiteSpace: "nowrap" }}>← 拖动对比 →</div>}
    </div>
  );
}

// ── 批量生成：1入N出网格 ───────────────────────────────────────────
function BatchGrid({ images, inputLabel }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: 280, background: "#000000" }}>
      <div style={{ padding: "12px 14px 0", display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        {/* 输入节点 */}
        <div style={{ background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: 6, padding: "5px 10px", fontSize: 11, color: T.textSub, whiteSpace: "nowrap", flexShrink: 0 }}>
          📝 {inputLabel || "1个需求"}
        </div>
        <div style={{ color: T.accent, fontSize: 13, fontWeight: 700, flexShrink: 0 }}>→</div>
        <div style={{ fontSize: 11, color: T.accent, fontWeight: 600, flexShrink: 0 }}>AI 批量生成 {images.length} 张</div>
      </div>
      {/* 输出缩略图网格 */}
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${Math.min(images.length, 4)}, 1fr)`, gap: 3, flex: 1, margin: "0 14px 14px 14px", overflow: "hidden", borderRadius: 6 }}>
        {images.slice(0, 4).map((src, i) => (
          <div key={i} style={{ position: "relative", paddingBottom: "56%", overflow: "hidden" }}>
            <img src={src} alt={`输出${i + 1}`} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
            {i === 3 && images.length > 4 && (
              <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#fff" }}>+{images.length - 4}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── 工作流步骤条（展开时显示）───────────────────────────────────────────────────
function FlowSteps({ steps }) {
  if (!steps?.length) return null;
  return (
    <div style={{ padding: "12px 14px 0", overflowX: "auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 0, minWidth: "max-content" }}>
        {steps.map((step, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              {/* 步骤圆点 */}
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: i === 0 ? T.bgSub : i === steps.length - 1 ? T.accentBg : T.bgSub, border: `1.5px solid ${i === steps.length - 1 ? T.accent : T.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, flexShrink: 0, fontWeight: 500 }}>
                {step.icon || (i + 1)}
              </div>
              {/* 步骤文字 */}
              <div style={{ fontSize: 10, color: i === steps.length - 1 ? T.accent : T.textSub, textAlign: "center", maxWidth: 60, lineHeight: 1.4, whiteSpace: "pre-wrap", fontWeight: 500 }}>{step.label}</div>
            </div>
            {/* 连接线 */}
            {i < steps.length - 1 && (
              <div style={{ width: 32, height: 1.5, background: T.border, flexShrink: 0, margin: "0 2px", marginBottom: 16 }} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── 通用：单图全宽 ─────────────────────────────────────────────────
function SingleImage({ src, isPlaceholder = false, title = "", stat = "" }) {
  if (isPlaceholder) {
    return (
      <div style={{ height: 280, background: `linear-gradient(135deg, ${T.accent}15, ${T.accent}08)`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, padding: 0 }}>
        <div style={{ fontSize: 48 }}>📊</div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 32, fontWeight: 700, color: T.accent, lineHeight: 1.2 }}>{stat}</div>
          <div style={{ fontSize: 12, color: T.textMute, marginTop: 12 }}>{title}</div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ height: 280, overflow: "hidden", position: "relative", background: "#000000", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <img src={src} alt="案例图" style={{ width: "100%", height: "100%", objectFit: "contain", objectPosition: "center" }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 60, background: "linear-gradient(transparent, #000000)", pointerEvents: "none" }} />
    </div>
  );
}

// ── 案例卡片主体 ───────────────────────────────────────────────────
function CaseCard({ item, onLike, onCopy }) {
  const [expanded, setExpanded] = useState(false);
  const [liked, setLiked] = useState(false);
  const catColor = CAT_COLOR[item.category] || T.textMute;

  // 自动判断卡片类型
  const steps = item.steps || null;
  const cardType = item.beforeAfter && item.images?.length >= 2 ? "compare"
    : steps?.length > 0                                          ? "flow"
    : item.images?.length > 1                                   ? "batch"
    : "text";

  const handleLike = (e) => {
    e.stopPropagation();
    if (liked) return;
    setLiked(true);
    onLike(item.id);
  };

  const timeBadge = (() => {
    const o = TIME_OPTIONS.find(t => t.min === item.timeSaved);
    if (o) return `${o.emoji} 省${o.label}时间`;
    return `⚡ 省 ${formatTime(item.timeSaved)}`;
  })();

  // 卡片类型角标
  const typeLabel = { compare: "对比", batch: "批量", flow: "流程", text: "分析" }[cardType];
  const typeLabelColor = { compare: T.green, batch: T.purple, flow: T.accent, text: T.textMute }[cardType];

  const cardBase = {
    background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius,
    overflow: "hidden", boxShadow: T.shadow, transition: "box-shadow 0.18s, border-color 0.18s",
    cursor: "pointer", display: "flex", flexDirection: "column",
  };

  const hover = { onMouseEnter: e => { e.currentTarget.style.boxShadow = T.shadowHover; e.currentTarget.style.borderColor = "#444"; }, onMouseLeave: e => { e.currentTarget.style.boxShadow = T.shadow; e.currentTarget.style.borderColor = T.border; } };

  return (
    <div style={cardBase} {...hover}>
      {/* ── 视觉区域（根据类型渲染不同组件）── */}
      {cardType === "compare" && (
        <div onClick={e => e.stopPropagation()}>
          <BeforeAfterSlider before={item.images[0]} after={item.images[1]} beforeLabel={item.beforeLabel} afterLabel={item.afterLabel} height={280} />
        </div>
      )}
      {cardType === "batch" && <BatchGrid images={item.images} inputLabel={item.inputLabel} />}
      {cardType === "flow" && item.images?.length > 0 && <SingleImage src={item.images[0]} />}
      {cardType === "text" && item.images?.length === 1 && <SingleImage src={item.images[0]} />}
      {cardType === "text" && (!item.images || item.images.length === 0) && <SingleImage isPlaceholder={true} title="准确率" stat="80%+" />}

      {/* ── 内容区 ── */}
      <div style={{ padding: "14px 16px 16px", flex: 1, display: "flex", flexDirection: "column" }} onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}>
        {/* 标签行 - 优化间距 */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <span style={{ fontSize: 10, background: `${catColor}18`, color: catColor, padding: "2px 8px", borderRadius: 20, fontWeight: 600, border: `1px solid ${catColor}30` }}>{item.category}</span>
            <span style={{ fontSize: 10, background: T.bgSub, color: T.textSub, padding: "2px 8px", borderRadius: 20, border: `1px solid ${T.border}`, fontWeight: 500 }}>{item.tool}</span>
            <span style={{ fontSize: 10, color: typeLabelColor, padding: "2px 8px", borderRadius: 20, border: `1px solid ${typeLabelColor}40`, background: `${typeLabelColor}12`, fontWeight: 500 }}>{typeLabel}</span>
          </div>
          <span style={{ fontSize: 10, color: T.textMute, whiteSpace: "nowrap", marginLeft: 8 }}>{item.date}</span>
        </div>

        {/* 标题 - 加大加粗 */}
        <div style={{ fontSize: 15, fontWeight: 700, color: T.text, marginBottom: 7, lineHeight: 1.5, letterSpacing: "-0.3px" }}>{item.title}</div>

        {/* 描述 - 改进行高和颜色 */}
        <div style={{ fontSize: 13, color: T.textSub, lineHeight: 1.75, marginBottom: 12, flex: 1,
          display: "-webkit-box", WebkitLineClamp: cardType === "text" ? 3 : 2, WebkitBoxOrient: "vertical", overflow: "hidden"
        }}>{item.desc}</div>

        {/* 底部：作者 + 省时 + 点赞 */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTop: `1px solid ${T.border}` }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ fontSize: 12, color: T.textMute, fontWeight: 500 }}>by {item.author}</span>
            <span style={{ fontSize: 11, color: T.orange, fontWeight: 600, background: "rgba(245,158,11,0.12)", padding: "2px 8px", borderRadius: 5, whiteSpace: "nowrap" }}>{timeBadge}</span>
          </div>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }} onClick={e => e.stopPropagation()}>
            <span style={{ fontSize: 13, fontWeight: 600, lineHeight: 1, minWidth: 60, textAlign: "left" }}>{item.rating}</span>
            <button onClick={handleLike}
              style={{ background: liked ? T.accent + "20" : "transparent", border: `1.5px solid ${liked ? T.accent : T.textMute}`, borderRadius: T.radiusSm, padding: "5px 10px", color: liked ? T.accent : T.textMute, fontSize: 12, cursor: liked ? "default" : "pointer", display: "flex", alignItems: "center", gap: 3, transition: "all 0.15s", fontWeight: liked ? 600 : 500, whiteSpace: "nowrap" }}
              onMouseEnter={e => !liked && (e.currentTarget.style.borderColor = T.accent, e.currentTarget.style.color = T.accent)}
              onMouseLeave={e => !liked && (e.currentTarget.style.borderColor = T.textMute, e.currentTarget.style.color = T.textMute)}>
              <span style={{ fontSize: 10, lineHeight: 1 }}>♥</span> {item.likes}
            </button>
          </div>
        </div>

        {/* Prompt 展开 + 流程步骤 */}
        {expanded && (
          <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${T.border}` }} onClick={e => e.stopPropagation()}>
            {/* 工作流步骤（仅在flow类型展示） */}
            {cardType === "flow" && steps?.length > 0 && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 10, color: T.textMute, marginBottom: 8, fontWeight: 700, letterSpacing: 0.8, textTransform: "uppercase" }}>工作流步骤</div>
                <FlowSteps steps={steps} />
              </div>
            )}

            {/* Prompt */}
            {item.prompt && (
              <div>
                <div style={{ fontSize: 10, color: T.textMute, marginBottom: 8, fontWeight: 700, letterSpacing: 0.8, textTransform: "uppercase" }}>Prompt</div>
                <div style={{ fontSize: 12, color: T.textSub, background: T.bg, borderRadius: T.radiusSm, padding: "12px 14px", lineHeight: 1.8, fontFamily: "'JetBrains Mono', monospace", whiteSpace: "pre-wrap", wordBreak: "break-all", border: `1px solid ${T.border}`, maxHeight: 180, overflowY: "auto" }}>
                  {item.prompt}
                </div>
                <button onClick={() => { navigator.clipboard?.writeText(item.prompt); onCopy("Prompt 已复制"); }}
                  style={{ marginTop: 8, background: "none", border: `1px solid ${T.border}`, borderRadius: T.radiusSm, padding: "5px 12px", color: T.textMute, fontSize: 11, cursor: "pointer", transition: "all 0.15s", fontWeight: 500 }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = T.accent; e.currentTarget.style.color = T.accent; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.color = T.textMute; }}>
                  ⌘ 复制 Prompt
                </button>
              </div>
            )}
          </div>
        )}
        {(item.prompt || (cardType === "flow" && steps?.length > 0)) && (
          <div style={{ textAlign: "center", marginTop: 8, color: T.textMute, fontSize: 10, fontWeight: 500 }}>{expanded ? "▲ 收起详情" : "▼ 查看详情"}</div>
        )}
      </div>
    </div>
  );
}

// ─── 省时选择器：音乐感知单位 ─────────────────────────────────────
// 替换分钟数输入，让填写者无需精确计算，感性估算即可
function TimeSavedPicker({ value, onChange }) {
  const selected = TIME_OPTIONS.find(o => o.min === Number(value));

  return (
    <div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 2 }}>
        {TIME_OPTIONS.map(opt => {
          const active = Number(value) === opt.min;
          return (
            <button key={opt.min} type="button" onClick={() => onChange(String(opt.min))}
              style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
                padding: "8px 10px", borderRadius: T.radius, cursor: "pointer",
                border: `1.5px solid ${active ? T.accent : T.border}`,
                background: active ? T.accentBg : T.bgSub,
                transition: "all 0.15s", minWidth: 62,
              }}
              onMouseEnter={e => { if (!active) { e.currentTarget.style.borderColor = T.accent + "60"; e.currentTarget.style.background = T.bgHover; } }}
              onMouseLeave={e => { if (!active) { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.background = T.bgSub; } }}>
              <span style={{ fontSize: 20, lineHeight: 1 }}>{opt.emoji}</span>
              <span style={{ fontSize: 11, fontWeight: active ? 600 : 400, color: active ? T.accent : T.text, whiteSpace: "nowrap" }}>{opt.label}</span>
              <span style={{ fontSize: 9, color: T.textMute }}>{opt.desc}</span>
            </button>
          );
        })}
      </div>
      {/* 选中后显示实际分钟，便于数据看板展示 */}
      {selected && (
        <div style={{ marginTop: 6, fontSize: 11, color: T.textMute }}>
          ≈ {formatTime(selected.min)} 将记入团队累计节省
        </div>
      )}
    </div>
  );
}

// ─── 工具栏：搜索 + 三个下拉（场景/工具/排序）──────────────────────
// 设计决策：用下拉代替横排 chip，从 30+ 按钮收纳到一行，减轻视觉压力
function FilterBar({ search, setSearch, filterCat, setFilterCat, filterTool, setFilterTool, sortBy, setSortBy, total }) {
  const selectStyle = {
    background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: T.radiusSm,
    padding: "7px 28px 7px 10px", color: filterCat !== "全部" ? T.accent : T.textSub,
    fontSize: 12, outline: "none", cursor: "pointer", appearance: "none",
    WebkitAppearance: "none", transition: "border-color 0.15s",
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%235A5A5A'/%3E%3C/svg%3E")`,
    backgroundRepeat: "no-repeat", backgroundPosition: "right 9px center",
  };

  return (
    <div style={{ marginBottom: 20 }}>
      {/* 一行：搜索框 + 三个下拉 + 结果数 */}
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        {/* 搜索框 */}
        <div style={{ position: "relative", flex: 1 }}>
          <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: T.textMute, fontSize: 14, pointerEvents: "none" }}>⌕</span>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="搜索案例、作者..."
            style={{ width: "100%", padding: "8px 12px 8px 34px", borderRadius: T.radiusSm, border: `1px solid ${T.border}`, background: T.bgSub, fontSize: 13, color: T.text, outline: "none", boxSizing: "border-box", transition: "border-color 0.15s" }}
            onFocus={e => e.target.style.borderColor = T.accent}
            onBlur={e => e.target.style.borderColor = T.border} />
          {search && (
            <button onClick={() => setSearch("")} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: T.textMute, fontSize: 14, cursor: "pointer", lineHeight: 1 }}>×</button>
          )}
        </div>

        {/* 场景下拉 */}
        <select value={filterCat} onChange={e => setFilterCat(e.target.value)}
          style={{ ...selectStyle, color: filterCat !== "全部" ? T.accent : T.textSub, borderColor: filterCat !== "全部" ? T.accent + "60" : T.border }}
          onFocus={e => e.target.style.borderColor = T.accent}
          onBlur={e => e.target.style.borderColor = filterCat !== "全部" ? T.accent + "60" : T.border}>
          <option value="全部">全部场景</option>
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>

        {/* 工具下拉 */}
        <select value={filterTool} onChange={e => setFilterTool(e.target.value)}
          style={{ ...selectStyle, color: filterTool !== "全部" ? T.accent : T.textSub, borderColor: filterTool !== "全部" ? T.accent + "60" : T.border }}
          onFocus={e => e.target.style.borderColor = T.accent}
          onBlur={e => e.target.style.borderColor = filterTool !== "全部" ? T.accent + "60" : T.border}>
          <option value="全部">全部工具</option>
          {TOOLS.map(t => <option key={t} value={t}>{t}</option>)}
        </select>

        {/* 排序下拉 */}
        <select value={sortBy} onChange={e => setSortBy(e.target.value)}
          style={{ ...selectStyle, color: T.textSub }}
          onFocus={e => e.target.style.borderColor = T.accent}
          onBlur={e => e.target.style.borderColor = T.border}>
          <option value="date">最新</option>
          <option value="likes">最多点赞</option>
          <option value="timeSaved">节省最多</option>
        </select>

        <span style={{ fontSize: 12, color: T.textMute, whiteSpace: "nowrap", flexShrink: 0 }}>{total} 条</span>
      </div>

      {/* 激活的筛选条件标签（有筛选才显示）*/}
      {(filterCat !== "全部" || filterTool !== "全部") && (
        <div style={{ display: "flex", gap: 6, marginTop: 8, alignItems: "center" }}>
          <span style={{ fontSize: 11, color: T.textMute }}>已筛选：</span>
          {filterCat !== "全部" && (
            <span style={{ fontSize: 11, background: T.accentBg, color: T.accent, border: `1px solid ${T.accent}30`, borderRadius: 4, padding: "2px 8px", display: "flex", alignItems: "center", gap: 4 }}>
              {filterCat} <button onClick={() => setFilterCat("全部")} style={{ background: "none", border: "none", color: T.accent, cursor: "pointer", fontSize: 12, padding: 0, lineHeight: 1 }}>×</button>
            </span>
          )}
          {filterTool !== "全部" && (
            <span style={{ fontSize: 11, background: T.accentBg, color: T.accent, border: `1px solid ${T.accent}30`, borderRadius: 4, padding: "2px 8px", display: "flex", alignItems: "center", gap: 4 }}>
              {filterTool} <button onClick={() => setFilterTool("全部")} style={{ background: "none", border: "none", color: T.accent, cursor: "pointer", fontSize: 12, padding: 0, lineHeight: 1 }}>×</button>
            </span>
          )}
        </div>
      )}
    </div>
  );
}

// ─── 图片上传组件 ─────────────────────────────────────────────────
function ImageUploader({ images, onChange }) {
  const fileRef = useRef(null);
  const addImage = (e) => {
    Array.from(e.target.files).forEach(f => {
      const reader = new FileReader();
      reader.onload = (ev) => onChange(prev => [...prev, { url: ev.target.result, type: f.type.startsWith("video") ? "video" : "image", name: f.name }]);
      reader.readAsDataURL(f);
    });
  };
  return (
    <div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
        {images.map((img, i) => (
          <div key={i} style={{ position: "relative", width: 88, height: 88, borderRadius: 8, overflow: "hidden", border: `1px solid ${T.border}` }}>
            {img.type === "video" ? (
              <div style={{ width: "100%", height: "100%", background: T.bgSub, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontSize: 10, color: T.orange, gap: 4 }}>
                <span style={{ fontSize: 18 }}>▶</span>
                <span style={{ fontSize: 10, color: T.textMute }}>{img.name.slice(0, 10)}</span>
              </div>
            ) : (
              <img src={img.url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            )}
            <button onClick={() => onChange(prev => prev.filter((_, j) => j !== i))}
              style={{ position: "absolute", top: 3, right: 3, width: 18, height: 18, borderRadius: "50%", background: "rgba(17,19,24,0.7)", border: "none", color: "#fff", fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
          </div>
        ))}
        <button onClick={() => fileRef.current?.click()}
          style={{ width: 88, height: 88, borderRadius: 8, border: `1.5px dashed ${T.border}`, background: T.bgSub, color: T.textMute, fontSize: 12, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, transition: "border-color 0.15s" }}
          onMouseEnter={e => e.currentTarget.style.borderColor = T.accent}
          onMouseLeave={e => e.currentTarget.style.borderColor = T.border}>
          <span style={{ fontSize: 20, lineHeight: 1, color: T.textMute }}>+</span>
          <span>上传</span>
        </button>
      </div>
      <input ref={fileRef} type="file" accept="image/*,video/*" multiple onChange={addImage} style={{ display: "none" }} />
      <div style={{ fontSize: 11, color: T.textMute }}>支持图片和视频，可上传截图、录屏、Before/After 对比图</div>
    </div>
  );
}

// ─── 表单输入样式 ─────────────────────────────────────────────────
const inputStyle = {
  background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: T.radiusSm,
  padding: "9px 12px", color: T.text, fontSize: 13, outline: "none",
  width: "100%", transition: "border-color 0.15s", boxSizing: "border-box",
};
const labelStyle = { fontSize: 12, color: T.textSub, marginBottom: 5, display: "block", fontWeight: 500 };

// ─── 主应用 ───────────────────────────────────────────────────────
export default function PracticeHub() {
  const [tab, setTab] = useState("browse");
  const [cases, setCases] = useState([]);
  const [allCases, setAllCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterCat, setFilterCat] = useState("全部");
  const [filterTool, setFilterTool] = useState("全部");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("date");          // date | likes | timeSaved
  const [form, setForm] = useState({ id: null, author: "", category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0], beforeAfter: false });
  const [uploadedImages, setUploadedImages] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [reportText, setReportText] = useState("");
  const [toast, setToast] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [currentUser, setCurrentUser] = useState(null); // 认证后的用户
  const [authName, setAuthName] = useState(""); // 认证输入框-花名
  const [authCode, setAuthCode] = useState(""); // 认证输入框-暗号

  const showToast = (msg) => { setToast(msg); };

  // ── 用户认证 ─────────────────────────────────────────────────
  const handleAuth = () => {
    if (!authName.trim()) {
      showToast("请输入花名");
      return;
    }
    if (authCode !== "163") {
      showToast("暗号错误");
      setAuthCode("");
      return;
    }
    setCurrentUser(authName.trim());
    setForm({ ...form, author: authName.trim() });
    setAuthName("");
    setAuthCode("");
    showToast(`欢迎 ${authName.trim()}`);
  };

  // ── 拉取案例（带筛选参数，服务端过滤）─────────────────────────
  const fetchCases = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filterCat !== "全部") params.set("category", filterCat);
      if (filterTool !== "全部") params.set("tool", filterTool);
      if (search) params.set("search", search);
      const res = await fetch(`/api/cases?${params}`);
      const data = await res.json();
      setCases(data.cases || []);
    } catch (err) {
      console.error("拉取案例失败", err);
    } finally {
      setLoading(false);
    }
  }, [filterCat, filterTool, search]);

  useEffect(() => { fetchCases(); }, [fetchCases]);

  // ── 全量数据（用于统计看板，不受筛选影响）────────────────────
  useEffect(() => {
    fetch("/api/cases").then(r => r.json()).then(d => setAllCases(d.cases || []));
  }, [cases]);

  // ── 前端排序（筛选后再排）────────────────────────────────────
  const sortedCases = useMemo(() => {
    return [...cases].sort((a, b) => {
      if (sortBy === "likes")     return b.likes - a.likes;
      if (sortBy === "timeSaved") return b.timeSaved - a.timeSaved;
      return new Date(b.date) - new Date(a.date);
    });
  }, [cases, sortBy]);

  // ── 统计数据 ─────────────────────────────────────────────────
  const stats = useMemo(() => {
    const thisWeek = allCases.filter(c => (new Date() - new Date(c.date)) / 864e5 <= 7);
    const totalMin = allCases.reduce((s, c) => s + c.timeSaved, 0);
    const authors = new Set(allCases.map(c => c.author));
    const topCase = [...allCases].sort((a, b) => b.likes - a.likes)[0];
    const toolCounts = Object.entries(allCases.reduce((a, c) => { a[c.tool] = (a[c.tool] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    const catCounts = Object.entries(allCases.reduce((a, c) => { a[c.category] = (a[c.category] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    const avgSaved = allCases.length ? Math.round(totalMin / allCases.length) : 0;
    return { total: allCases.length, thisWeek: thisWeek.length, totalHours: Math.round(totalMin / 60), authors: authors.size, topCase, toolCounts, catCounts, avgSaved };
  }, [allCases]);

  // ── 提交案例 ─────────────────────────────────────────────────
  const handleSubmit = async () => {
    if (!form.title || !form.desc || !form.timeSaved || submitting) {
      if (!form.timeSaved) {
        showToast("请选择节省的时间");
      }
      return;
    }
    setSubmitting(true);
    try {
      const imgs = uploadedImages.map(i => i.url);
      const hasVideo = uploadedImages.some(i => i.type === "video");
      const isEditing = form.id !== null;
      const payload = {
        ...form,
        id: undefined, // 不发送 id 给 API（API 用 URL 参数识别）
        images: imgs,
        hasVideo,
        timeSaved: parseInt(form.timeSaved) || 0,
        beforeLabel: form.beforeAfter ? "改造前" : null,
        afterLabel: form.beforeAfter ? "改造后" : null,
      };
      delete payload.id; // 确保不发送 id

      const res = await fetch(
        isEditing ? `/api/cases/${form.id}` : "/api/cases",
        {
          method: isEditing ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) throw new Error();
      const data = await res.json();
      const updatedCase = data.case;

      // 更新状态
      if (isEditing) {
        setCases(prev => prev.map(c => c.id === form.id ? updatedCase : c));
        setAllCases(prev => prev.map(c => c.id === form.id ? updatedCase : c));
        showToast("案例已更新");
      } else {
        setCases(prev => [updatedCase, ...prev]);
        setAllCases(prev => [updatedCase, ...prev]);
        showToast("提交成功！");
        // 立即跳转到案例库
        setTimeout(() => { setTab("browse"); setSearch(""); }, 300);
      }

      // 重置表单
      setForm({ id: null, author: form.author, category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0], beforeAfter: false });
      setUploadedImages([]);
    } catch {
      showToast(form.id ? "更新失败，请重试" : "提交失败，请重试");
    } finally {
      setSubmitting(false);
    }
  };

  // ── 点赞（乐观更新）─────────────────────────────────────────
  const handleLike = async (id) => {
    setCases(prev => prev.map(c => c.id === id ? { ...c, likes: c.likes + 1 } : c));
    showToast("已点赞 👍");
    try { await fetch(`/api/cases/${id}/like`, { method: "POST" }); }
    catch { console.error("点赞失败"); }
  };

  // ── 周报生成 ─────────────────────────────────────────────────
  const generateReport = () => {
    const thisWeek = allCases.filter(c => (new Date() - new Date(c.date)) / 864e5 <= 7);
    const totalMin = thisWeek.reduce((s, c) => s + c.timeSaved, 0);
    const authors = [...new Set(thisWeek.map(c => c.author))];
    const top3 = [...thisWeek].sort((a, b) => b.likes - a.likes).slice(0, 3);
    const toolCount = Object.entries(thisWeek.reduce((a, c) => { a[c.tool] = (a[c.tool] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    const withImages = thisWeek.filter(c => c.images?.length > 0).length;
    let r = `📊 设计团队 AI 实践周报\n${"─".repeat(32)}\n\n`;
    r += `📅 周期：最近7天\n👥 参与：${authors.length}人（${authors.join("、")}）\n📝 案例：${thisWeek.length}条（含${withImages}条视觉案例）\n⏱️ 节省：${formatTime(totalMin)}\n\n`;
    r += `🏆 Top 案例\n`;
    top3.forEach((c, i) => { r += `  ${i + 1}. 「${c.title}」by ${c.author}\n     ${c.desc.slice(0, 50)}...\n     省时${formatTime(c.timeSaved)} · ${c.likes}人推荐\n\n`; });
    r += `🔧 工具使用：${toolCount.map(([t, n]) => `${t}(${n}次)`).join(" / ")}\n\n`;
    r += `📌 趋势：${stats.catCounts[0] ? `${stats.catCounts[0][0]}场景最活跃` : ""}，${thisWeek.length > 3 ? "团队AI实践持续增长" : "建议推动更多场景试点"}`;
    return r;
  };

  // ── Tab 样式 ─────────────────────────────────────────────────
  const tabStyle = (t) => ({
    padding: "7px 16px", borderRadius: 7, border: "none",
    background: tab === t ? T.accentBg : "transparent",
    color: tab === t ? T.accent : T.textSub,
    fontSize: 13, fontWeight: tab === t ? 600 : 400,
    cursor: "pointer", transition: "all 0.15s", whiteSpace: "nowrap",
    borderBottom: tab === t ? `2px solid ${T.accent}` : "2px solid transparent",
  });

  return (
    <div style={{ minHeight: "100vh", background: T.bg, color: T.text, fontFamily: "'Noto Sans SC', 'Inter', -apple-system, sans-serif" }}>
      {toast && <Toast msg={toast} onClose={() => setToast(null)} />}

      {/* ── 顶部导航栏 ── */}
      <header style={{ background: T.bgCard, borderBottom: `1px solid ${T.border}`, position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: 1080, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 50 }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
            <div style={{ width: 26, height: 26, borderRadius: 7, background: `linear-gradient(135deg, ${T.accent}, #0D8A84)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>✦</div>
            <span style={{ fontSize: 14, fontWeight: 700, color: T.text }}>AI 实践看板</span>
          </div>
          {/* Tab 导航居中 */}
          <div style={{ display: "flex", gap: 0 }}>
            {[["browse", "案例库"], ["dashboard", "数据看板"], ["submit", "提交案例"], ["report", "周报"]].map(([k, v]) => (
              <button key={k} style={tabStyle(k)} onClick={() => { setTab(k); if (k === "report") setReportText(generateReport()); }}>{v}</button>
            ))}
          </div>
          {/* 右侧：认证状态 + 案例数徽标 */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
            {currentUser && (
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: T.accent, background: T.accentBg, border: `1px solid ${T.accent}`, borderRadius: 5, padding: "4px 10px" }}>
                <span>👤 {currentUser}</span>
                <button onClick={() => { setCurrentUser(null); setForm({ ...form, author: "" }); showToast("已退出"); }}
                  style={{ background: "none", border: "none", color: T.accent, cursor: "pointer", fontSize: 12, padding: 0, textDecoration: "underline" }}>
                  退出
                </button>
              </div>
            )}
            <div style={{ fontSize: 12, color: T.textMute, background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: 5, padding: "3px 9px" }}>
              {stats.total} 个案例
            </div>
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 1080, margin: "0 auto", padding: "28px 24px 80px" }}>

        {/* ══ 案例库 ══ */}
        {tab === "browse" && (
          <div>
            {/* 搜索+筛选+排序 合并为一行 */}
            <FilterBar search={search} setSearch={setSearch} filterCat={filterCat} setFilterCat={setFilterCat} filterTool={filterTool} setFilterTool={setFilterTool} sortBy={sortBy} setSortBy={setSortBy} total={sortedCases.length} />

            {/* 卡片列表 - 2 列网格 */}
            {loading ? (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[1,2,3,4].map(i => (
                  <div key={i} style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius, height: 280, boxShadow: T.shadow, animation: "pulse 1.5s ease-in-out infinite", opacity: 0.5 }} />
                ))}
              </div>
            ) : sortedCases.length === 0 ? (
              <div style={{ textAlign: "center", padding: "64px 0", color: T.textMute }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>🔍</div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>没有找到匹配的案例</div>
                <div style={{ fontSize: 12, marginTop: 6 }}>换个筛选条件，或者成为第一个提交的人</div>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {sortedCases.map(c => <CaseCard key={c.id} item={c} onLike={handleLike} onCopy={showToast} />)}
              </div>
            )}
          </div>
        )}

        {/* ══ 数据看板 ══ */}
        {tab === "dashboard" && (
          <div>
            {/* 统计卡片 */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
              <StatCard icon="📝" label="案例总数" value={stats.total} sub="持续积累中" accent={T.accent} />
              <StatCard icon="📅" label="本周新增" value={stats.thisWeek} sub="最近7天" accent={T.green} />
              <StatCard icon="⚡" label="累计节省" value={`${stats.totalHours}h`} sub={`${stats.total}个案例 · 平均${formatTime(stats.avgSaved)}/案例`} accent={T.orange} />
              <StatCard icon="👥" label="参与设计师" value={stats.authors} sub="人均节省 · 持续增长" accent={T.purple} />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              {/* 工具热度 */}
              <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: 22, boxShadow: T.shadow }}>
                <div style={{ fontSize: 12, color: T.textMute, marginBottom: 16, fontWeight: 600, letterSpacing: 0.3, textTransform: "uppercase" }}>工具热度排行</div>
                {stats.toolCounts.slice(0, 6).map(([tool, count], i) => (
                  <div key={tool} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                    <span style={{ fontSize: 11, color: T.textMute, width: 16, textAlign: "right" }}>{i + 1}</span>
                    <span style={{ fontSize: 13, color: T.text, flex: 1, fontWeight: i === 0 ? 600 : 400 }}>{tool}</span>
                    <div style={{ width: 120, height: 5, background: T.bgSub, borderRadius: 3, overflow: "hidden" }}>
                      <div style={{ width: `${(count / (stats.toolCounts[0]?.[1] || 1)) * 100}%`, height: "100%", background: i === 0 ? T.accent : `${T.accent}60`, borderRadius: 3, transition: "width 0.6s ease" }} />
                    </div>
                    <span style={{ fontSize: 12, color: T.textMute, width: 20, textAlign: "right" }}>{count}</span>
                  </div>
                ))}
              </div>

              {/* 场景分布 */}
              <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: 22, boxShadow: T.shadow }}>
                <div style={{ fontSize: 12, color: T.textMute, marginBottom: 16, fontWeight: 600, letterSpacing: 0.3, textTransform: "uppercase" }}>场景分布</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {stats.catCounts.map(([cat, count]) => {
                    const color = CAT_COLOR[cat] || T.textMute;
                    return (
                      <div key={cat} style={{ background: `${color}10`, border: `1px solid ${color}25`, borderRadius: 8, padding: "8px 14px", display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ fontSize: 12, color: T.textSub }}>{cat}</span>
                        <span style={{ fontSize: 15, color: color, fontWeight: 700 }}>{count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* 最受欢迎案例 */}
            {stats.topCase && (
              <div style={{ background: `linear-gradient(135deg, ${T.accentBg}, #1A2E2E)`, border: `1px solid ${T.accent}30`, borderRadius: T.radius, padding: 22, boxShadow: T.shadow }}>
                <div style={{ fontSize: 12, color: T.accent, marginBottom: 10, fontWeight: 600, letterSpacing: 0.3, textTransform: "uppercase" }}>🏆 最受欢迎案例</div>
                <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 6, color: T.text }}>{stats.topCase.title}</div>
                <div style={{ fontSize: 13, color: T.textSub }}>
                  by {stats.topCase.author}
                  <span style={{ margin: "0 8px", color: T.border }}>·</span>
                  {stats.topCase.likes} 人点赞
                  <span style={{ margin: "0 8px", color: T.border }}>·</span>
                  省时 {formatTime(stats.topCase.timeSaved)}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ 提交案例 ══ */}
        {tab === "submit" && (
          <div>
            {submitted ? (
              <div style={{ textAlign: "center", padding: "80px 0", background: T.bgCard, borderRadius: T.radius, border: `1px solid ${T.border}`, boxShadow: T.shadow }}>
                <div style={{ fontSize: 44, marginBottom: 16 }}>🎉</div>
                <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6, color: T.text }}>提交成功！</div>
                <div style={{ fontSize: 13, color: T.textMute }}>感谢你的分享，正在跳转...</div>
              </div>
            ) : !currentUser ? (
              // 未认证：显示认证框
              <div style={{ maxWidth: 400, margin: "40px auto" }}>
                <div style={{ background: T.bgCard, border: `2px solid ${T.accent}`, borderRadius: T.radius, padding: 32, boxShadow: T.shadow }}>
                  <div style={{ fontSize: 20, fontWeight: 700, color: T.text, marginBottom: 8, textAlign: "center" }}>🔐 身份验证</div>
                  <div style={{ fontSize: 13, color: T.textMute, marginBottom: 24, textAlign: "center", lineHeight: 1.6 }}>
                    输入花名和暗号才能提交、编辑和查看你的案例<br/>浏览和点赞无需验证
                  </div>

                  <div style={{ marginBottom: 16 }}>
                    <label style={labelStyle}>花名 *</label>
                    <input style={inputStyle} value={authName} onChange={e => setAuthName(e.target.value)} placeholder="输入你的花名"
                      onFocus={e => e.target.style.borderColor = T.accent} onBlur={e => e.target.style.borderColor = T.border}
                      onKeyPress={e => e.key === "Enter" && authCode && handleAuth()} />
                  </div>

                  <div style={{ marginBottom: 24 }}>
                    <label style={labelStyle}>暗号 *</label>
                    <input type="password" style={inputStyle} value={authCode} onChange={e => setAuthCode(e.target.value)} placeholder="输入暗号"
                      onFocus={e => e.target.style.borderColor = T.accent} onBlur={e => e.target.style.borderColor = T.border}
                      onKeyPress={e => e.key === "Enter" && handleAuth()} />
                  </div>

                  <button onClick={handleAuth} style={{ width: "100%", background: T.accent, border: "none", borderRadius: T.radius, padding: "12px 0", color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer", transition: "all 0.2s" }}
                    onMouseEnter={e => e.currentTarget.style.opacity = "0.9"} onMouseLeave={e => e.currentTarget.style.opacity = "1"}>
                    进入
                  </button>
                </div>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 24 }}>
              {/* ─── 左侧：提交表单 ───────────────────────────────── */}
              <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: 28, boxShadow: T.shadow, display: "flex", flexDirection: "column", gap: 18, height: "fit-content", position: "sticky", top: 100 }}>
                <div>
                  <div style={{ fontSize: 17, fontWeight: 700, color: T.text, marginBottom: 4 }}>分享你的 AI 实践</div>
                  <div style={{ fontSize: 13, color: T.textMute, lineHeight: 1.7 }}>不需要完美，真实就好。你的 Prompt 可能帮到下一个人。</div>
                </div>

                <div style={{ height: 1, background: T.border }} />

                <div style={{ background: T.accentBg, border: `1px solid ${T.accent}`, borderRadius: T.radiusSm, padding: 12 }}>
                  <div style={{ fontSize: 12, color: T.accent, fontWeight: 600 }}>👤 当前用户: {currentUser}</div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                  <div>
                    <label style={labelStyle}>大概省了多少时间？</label>
                    <TimeSavedPicker value={form.timeSaved} onChange={v => setForm({ ...form, timeSaved: v })} />
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
                  {[["场景", "category", CATEGORIES], ["工具", "tool", TOOLS], ["效果评级", "rating", RATINGS]].map(([label, key, options]) => (
                    <div key={key}>
                      <label style={labelStyle}>{label}</label>
                      <select style={{ ...inputStyle, cursor: "pointer" }} value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })}
                        onFocus={e => e.target.style.borderColor = T.accent} onBlur={e => e.target.style.borderColor = T.border}>
                        {options.map(o => <option key={o}>{o}</option>)}
                      </select>
                    </div>
                  ))}
                </div>

                <div>
                  <label style={labelStyle}>一句话说清楚 *</label>
                  <input style={inputStyle} value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="例：用即梦批量生成8张会员Banner，省了2天工作量"
                    onFocus={e => e.target.style.borderColor = T.accent} onBlur={e => e.target.style.borderColor = T.border} />
                </div>

                <div>
                  <label style={labelStyle}>详细说说 *</label>
                  <textarea style={{ ...inputStyle, minHeight: 88, resize: "vertical" }} value={form.desc} onChange={e => setForm({ ...form, desc: e.target.value })} placeholder="怎么做的？效果怎样？踩了什么坑？数据越具体越好..."
                    onFocus={e => e.target.style.borderColor = T.accent} onBlur={e => e.target.style.borderColor = T.border} />
                </div>

                <div>
                  <label style={labelStyle}>上传截图/视频</label>
                  <ImageUploader images={uploadedImages} onChange={setUploadedImages} />
                  {uploadedImages.length >= 2 && (
                    <label style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 10, cursor: "pointer", fontSize: 12, color: T.textSub }}>
                      <input type="checkbox" checked={form.beforeAfter} onChange={e => setForm({ ...form, beforeAfter: e.target.checked })} style={{ accentColor: T.accent, width: 14, height: 14 }} />
                      前两张图作为 Before / After 对比展示
                    </label>
                  )}
                </div>

                <div>
                  <label style={labelStyle}>Prompt / 操作步骤（可选，强烈建议填）</label>
                  <textarea style={{ ...inputStyle, minHeight: 72, resize: "vertical", fontFamily: "'JetBrains Mono', 'SF Mono', monospace", fontSize: 12 }} value={form.prompt} onChange={e => setForm({ ...form, prompt: e.target.value })} placeholder="贴上你用的 Prompt，或者写操作步骤，方便他人复用"
                    onFocus={e => e.target.style.borderColor = T.accent} onBlur={e => e.target.style.borderColor = T.border} />
                </div>

                <div style={{ display: "flex", gap: 12 }}>
                  <button onClick={handleSubmit} disabled={!form.title || !form.desc || !form.timeSaved || submitting}
                    style={{ flex: 1, background: form.title && form.desc && form.timeSaved ? T.accent : T.bgSub, border: "none", borderRadius: T.radius, padding: "12px 0", color: form.title && form.desc && form.timeSaved ? "#fff" : T.textMute, fontSize: 14, fontWeight: 600, cursor: form.title && form.desc && form.timeSaved ? "pointer" : "not-allowed", transition: "all 0.2s", letterSpacing: 0.2 }}>
                    {submitting ? (form.id ? "更新中..." : "提交中...") : (form.id ? "更新案例 ↻" : "提交案例 →")}
                  </button>
                  {form.id && (
                    <button onClick={() => {
                      setForm({ id: null, author: form.author, category: CATEGORIES[0], tool: TOOLS[0], title: "", desc: "", prompt: "", timeSaved: "", rating: RATINGS[0], beforeAfter: false });
                      setUploadedImages([]);
                    }}
                      style={{ flex: 1, background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: "12px 0", color: T.textMute, fontSize: 14, fontWeight: 600, cursor: "pointer", transition: "all 0.2s", letterSpacing: 0.2 }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor = T.textMute; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; }}>
                      取消编辑
                    </button>
                  )}
                </div>
              </div>

              {/* ─── 右侧：提交记录列表 ───────────────────────────── */}
              <div>
                <div style={{ position: "sticky", top: 100 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: T.text, marginBottom: 14 }}>
                    📝 我的提交 <span style={{ fontSize: 12, color: T.textMute, fontWeight: 400 }}>({allCases.filter(c => c.author === currentUser).length})</span>
                  </div>
                  {allCases.filter(c => c.author === currentUser).length === 0 ? (
                        <div style={{ background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: T.radiusSm, padding: 12, textAlign: "center", color: T.textMute }}>
                          <div style={{ fontSize: 12 }}>暂无提交</div>
                        </div>
                      ) : (
                      <div style={{ display: "flex", flexDirection: "column", gap: 10, maxHeight: "600px", overflowY: "auto" }}>
                    {allCases.filter(c => c.author === currentUser).map(c => (
                      <div key={c.id} style={{ background: T.bgSub, border: `1px solid ${T.border}`, borderRadius: T.radiusSm, padding: 12, cursor: "pointer", transition: "all 0.15s", display: "flex", flexDirection: "column", gap: 8 }}
                        onMouseEnter={e => { e.currentTarget.style.borderColor = T.accent; e.currentTarget.style.background = T.bgHover; }}
                        onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.background = T.bgSub; }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: T.text, display: "flex", gap: 4, alignItems: "center" }}>
                          <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{c.title}</span>
                        </div>
                        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                          <button onClick={() => {
                            setForm({ ...c, id: c.id, timeSaved: String(c.timeSaved), beforeAfter: c.beforeAfter || false });
                            setUploadedImages(c.images && c.images.length > 0 ? c.images.map(url => ({ url, type: c.hasVideo ? 'video' : 'image' })) : []);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                            showToast("已加载用于编辑");
                          }}
                            style={{ flex: 1, background: T.accent, border: "none", borderRadius: T.radiusSm, padding: "4px 8px", color: "#fff", fontSize: 11, cursor: "pointer", transition: "all 0.15s", fontWeight: 600 }}
                            onMouseEnter={e => { e.currentTarget.style.opacity = "0.9"; }}
                            onMouseLeave={e => { e.currentTarget.style.opacity = "1"; }}>
                            编辑
                          </button>
                          <button onClick={async (e) => {
                            e.stopPropagation();
                            if (deletingId === c.id) {
                              // 第二次点击，执行删除
                              try {
                                await fetch(`/api/cases/${c.id}`, { method: 'DELETE' });
                                setCases(prev => prev.filter(x => x.id !== c.id));
                                setAllCases(prev => prev.filter(x => x.id !== c.id));
                                showToast("案例已删除");
                                setDeletingId(null);
                              } catch {
                                showToast("删除失败");
                              }
                            } else {
                              // 第一次点击，标记为待删除状态
                              setDeletingId(c.id);
                            }
                          }}
                            style={{ flex: 1, background: deletingId === c.id ? "#991b1b" : "#dc2626", border: "none", borderRadius: T.radiusSm, padding: "4px 8px", color: "#fff", fontSize: 11, cursor: "pointer", transition: "all 0.15s", fontWeight: 600 }}
                            onMouseEnter={e => { e.currentTarget.style.opacity = "0.9"; }}
                            onMouseLeave={e => { e.currentTarget.style.opacity = "1"; }}>
                            {deletingId === c.id ? "确认删除" : "删除"}
                          </button>
                        </div>
                      </div>
                      ))}
                      </div>
                      )}
                </div>
              </div>
            </div>
            )}
          </div>
        )}

        {/* ══ 周报 ══ */}
        {tab === "report" && (
          <div style={{ maxWidth: 640 }}>
            <div style={{ fontSize: 13, color: T.textMute, marginBottom: 16, lineHeight: 1.7 }}>
              基于最近7天数据自动生成，直接复制粘贴发给负责人。
            </div>
            <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: 24, boxShadow: T.shadow }}>
              <pre style={{ fontSize: 13, color: T.textSub, lineHeight: 2, whiteSpace: "pre-wrap", margin: 0, fontFamily: "'Noto Sans SC', sans-serif" }}>{reportText}</pre>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
              <button onClick={() => { navigator.clipboard?.writeText(reportText); showToast("周报已复制到剪贴板"); }}
                style={{ background: T.accent, border: "none", borderRadius: T.radius, padding: "10px 22px", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer", transition: "opacity 0.15s" }}
                onMouseEnter={e => e.currentTarget.style.opacity = "0.85"}
                onMouseLeave={e => e.currentTarget.style.opacity = "1"}>
                复制周报
              </button>
              <button onClick={() => setReportText(generateReport())}
                style={{ background: T.bg, border: `1px solid ${T.border}`, borderRadius: T.radius, padding: "10px 22px", color: T.textSub, fontSize: 13, cursor: "pointer", transition: "border-color 0.15s" }}
                onMouseEnter={e => e.currentTarget.style.borderColor = T.accent}
                onMouseLeave={e => e.currentTarget.style.borderColor = T.border}>
                重新生成
              </button>
            </div>
          </div>
        )}

      </main>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        @keyframes pulse { 0%,100%{opacity:0.5} 50%{opacity:0.25} }
        select option { background: #242424; color: #EDEDEC; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #3A3A3A; border-radius: 2px; }
      `}</style>
    </div>
  );
}
