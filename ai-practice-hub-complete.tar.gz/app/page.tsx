// 主页：挂载 AI 实践看板客户端组件
import PracticeHub from './PracticeHub';

export default function Home() {
  return <PracticeHub />;
}
