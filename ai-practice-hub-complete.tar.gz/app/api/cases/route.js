// API 路由：案例列表（GET 获取 / POST 新增）
import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

// GET /api/cases — 返回所有案例，支持 category / tool / search 筛选
export async function GET(request) {
  try {
    const db = getDb();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const tool = searchParams.get('tool');
    const search = searchParams.get('search');

    let sql = 'SELECT * FROM cases WHERE 1=1';
    const params = [];

    if (category) { sql += ' AND category = ?'; params.push(category); }
    if (tool)     { sql += ' AND tool = ?';     params.push(tool); }
    if (search)   { sql += ' AND (title LIKE ? OR desc LIKE ? OR author LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

    sql += ' ORDER BY date DESC, id DESC';

    const rows = db.prepare(sql).all(...params);

    // 将数据库字段名转成前端用的驼峰命名
    const cases = rows.map(formatCase);
    return NextResponse.json({ cases });
  } catch (err) {
    console.error('[GET /api/cases]', err);
    return NextResponse.json({ error: '获取案例失败' }, { status: 500 });
  }
}

// POST /api/cases — 新增一条案例
export async function POST(request) {
  try {
    const db = getDb();
    const body = await request.json();
    const { author, category, tool, title, desc, prompt, timeSaved, rating, images, beforeAfter, beforeLabel, afterLabel, hasVideo, steps, inputLabel } = body;

    if (!author || !title || !desc) {
      return NextResponse.json({ error: '作者、标题、描述为必填项' }, { status: 400 });
    }

    const stmt = db.prepare(`
      INSERT INTO cases (author, date, category, tool, title, desc, prompt, time_saved, rating, images, has_video, before_after, before_label, after_label, steps, input_label)
      VALUES (?, date('now'), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      author, category, tool, title, desc,
      prompt || '',
      parseInt(timeSaved) || 0,
      rating || '👍 有效果',
      JSON.stringify(images || []),
      hasVideo ? 1 : 0,
      beforeAfter ? 1 : 0,
      beforeLabel || null,
      afterLabel || null,
      steps ? JSON.stringify(steps) : '[]',
      inputLabel || null
    );

    const newCase = db.prepare('SELECT * FROM cases WHERE id = ?').get(result.lastInsertRowid);
    return NextResponse.json({ case: formatCase(newCase) }, { status: 201 });
  } catch (err) {
    console.error('[POST /api/cases]', err);
    return NextResponse.json({ error: '提交案例失败' }, { status: 500 });
  }
}

// 将数据库下划线字段转为驼峰，images JSON 字符串转为数组
function formatCase(row) {
  return {
    id:          row.id,
    author:      row.author,
    date:        row.date,
    category:    row.category,
    tool:        row.tool,
    title:       row.title,
    desc:        row.desc,
    prompt:      row.prompt,
    timeSaved:   row.time_saved,
    rating:      row.rating,
    likes:       row.likes,
    hasVideo:    row.has_video === 1,
    beforeAfter: row.before_after === 1,
    beforeLabel: row.before_label,
    afterLabel:  row.after_label,
    inputLabel:  row.input_label,
    steps:       row.steps ? JSON.parse(row.steps) : [],
    images:      JSON.parse(row.images || '[]'),
  };
}
