// API 路由：点赞 POST /api/cases/[id]/like
import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function POST(request, { params }) {
  try {
    const db = getDb();
    const { id } = await params;
    const numId = parseInt(id);

    if (isNaN(numId)) {
      return NextResponse.json({ error: '无效的案例 ID' }, { status: 400 });
    }

    // 检查案例是否存在
    const existing = db.prepare('SELECT id, likes FROM cases WHERE id = ?').get(numId);
    if (!existing) {
      return NextResponse.json({ error: '案例不存在' }, { status: 404 });
    }

    // 点赞数 +1
    db.prepare('UPDATE cases SET likes = likes + 1 WHERE id = ?').run(numId);
    const updated = db.prepare('SELECT likes FROM cases WHERE id = ?').get(numId);

    return NextResponse.json({ likes: updated.likes });
  } catch (err) {
    console.error('[POST /api/cases/[id]/like]', err);
    return NextResponse.json({ error: '点赞失败' }, { status: 500 });
  }
}
