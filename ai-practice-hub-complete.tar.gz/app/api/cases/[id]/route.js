// API 路由：获取/编辑单个案例
import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

// GET 单个案例
export async function GET(request, { params }) {
  try {
    const { id } = await params;
    const db = getDb();

    const row = db.prepare('SELECT * FROM cases WHERE id = ?').get(id);
    if (!row) {
      return NextResponse.json({ error: '案例不存在' }, { status: 404 });
    }

    const caseData = {
      id: row.id,
      author: row.author,
      date: row.date,
      category: row.category,
      tool: row.tool,
      title: row.title,
      desc: row.desc,
      prompt: row.prompt,
      timeSaved: row.time_saved,
      rating: row.rating,
      likes: row.likes,
      hasVideo: row.has_video === 1,
      beforeAfter: row.before_after === 1,
      beforeLabel: row.before_label,
      afterLabel: row.after_label,
      inputLabel: row.input_label,
      steps: row.steps ? JSON.parse(row.steps) : [],
      images: JSON.parse(row.images || '[]'),
    };

    return NextResponse.json(caseData);
  } catch (err) {
    console.error('[GET /api/cases/[id]]', err);
    return NextResponse.json({ error: '获取案例失败' }, { status: 500 });
  }
}

// PUT 编辑案例
export async function PUT(request, { params }) {
  try {
    const { id } = await params;
    const db = getDb();
    const body = await request.json();

    const { author, category, tool, title, desc, prompt, timeSaved, rating, images, beforeAfter, beforeLabel, afterLabel, hasVideo, steps, inputLabel } = body;

    if (!title || !desc) {
      return NextResponse.json({ error: '标题和描述为必填项' }, { status: 400 });
    }

    const stmt = db.prepare(`
      UPDATE cases SET
        author = ?, category = ?, tool = ?, title = ?, desc = ?, prompt = ?,
        time_saved = ?, rating = ?, images = ?, has_video = ?, before_after = ?,
        before_label = ?, after_label = ?, steps = ?, input_label = ?
      WHERE id = ?
    `);

    const result = stmt.run(
      author || '未知',
      category || '',
      tool || '',
      title,
      desc,
      prompt || '',
      parseInt(timeSaved) || 0,
      rating || '👍 有效果',
      JSON.stringify(images || []),
      hasVideo ? 1 : 0,
      beforeAfter ? 1 : 0,
      beforeLabel || null,
      afterLabel || null,
      steps ? JSON.stringify(steps) : '[]',
      inputLabel || null,
      id
    );

    if (result.changes === 0) {
      return NextResponse.json({ error: '案例不存在' }, { status: 404 });
    }

    const updatedCase = db.prepare('SELECT * FROM cases WHERE id = ?').get(id);
    const caseData = {
      id: updatedCase.id,
      author: updatedCase.author,
      date: updatedCase.date,
      category: updatedCase.category,
      tool: updatedCase.tool,
      title: updatedCase.title,
      desc: updatedCase.desc,
      prompt: updatedCase.prompt,
      timeSaved: updatedCase.time_saved,
      rating: updatedCase.rating,
      likes: updatedCase.likes,
      hasVideo: updatedCase.has_video === 1,
      beforeAfter: updatedCase.before_after === 1,
      beforeLabel: updatedCase.before_label,
      afterLabel: updatedCase.after_label,
      inputLabel: updatedCase.input_label,
      steps: updatedCase.steps ? JSON.parse(updatedCase.steps) : [],
      images: JSON.parse(updatedCase.images || '[]'),
    };

    return NextResponse.json({ case: caseData, success: true });
  } catch (err) {
    console.error('[PUT /api/cases/[id]]', err);
    return NextResponse.json({ error: '更新失败' }, { status: 500 });
  }
}

// DELETE 删除案例
export async function DELETE(request, { params }) {
  try {
    const { id } = await params;
    const db = getDb();

    const stmt = db.prepare('DELETE FROM cases WHERE id = ?');
    const result = stmt.run(id);

    if (result.changes === 0) {
      return NextResponse.json({ error: '案例不存在' }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: '案例已删除' });
  } catch (err) {
    console.error('[DELETE /api/cases/[id]]', err);
    return NextResponse.json({ error: '删除失败' }, { status: 500 });
  }
}
