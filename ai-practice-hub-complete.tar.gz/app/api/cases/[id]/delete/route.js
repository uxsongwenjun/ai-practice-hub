// API 路由：删除案例
import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function DELETE(request, { params }) {
  try {
    const { id } = await params;
    const db = getDb();

    const stmt = db.prepare('DELETE FROM cases WHERE id = ?');
    const result = stmt.run(id);

    if (result.changes === 0) {
      return NextResponse.json({ error: '案例不存在' }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: '案例已删除' });
  } catch (err) {
    console.error('[DELETE /api/cases/[id]/delete]', err);
    return NextResponse.json({ error: '删除失败' }, { status: 500 });
  }
}
