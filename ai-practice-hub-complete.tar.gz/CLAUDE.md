# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

这是一个设计团队 AI 实践平台的前端原型集合，包含策略文档和 React 组件原型。目标是部署到团队内网服务器，供设计师提交和浏览 AI 使用案例。

## 文件说明

| 文件 | 用途 |
|------|------|
| `ai_practice_hub_v2.jsx` | 主组件，当前最新版本，含图片上传和 Before/After 对比功能 |
| `ai_practice_hub.jsx` | v1 原型，功能较简，可作参考对比 |
| `ai_practice_hub_requirements.html` | 部署需求说明文档（服务器环境、认证方案、功能清单） |
| `ai_design_workflow_strategy.html` | AI 流程搭建策略文档（背景材料，非代码） |

## 技术栈与部署目标

- **框架**：Next.js（React）— JSX 组件需在 Next.js 项目中运行
- **数据库**：SQLite（单文件）或 PostgreSQL
- **文件存储**：服务器本地 `/uploads` 目录
- **认证**：第一阶段为邀请码（无需外部系统），第二阶段对接公司 SSO（OAuth2）

## 核心数据结构

案例对象（Case）的字段：
```js
{
  id, author, date, category, tool, title,
  desc, prompt, timeSaved,  // 单位：分钟
  rating, likes,
  images,      // URL 数组
  hasVideo,    // boolean
  beforeAfter, // boolean，是否展示 Before/After 对比图
  beforeLabel, afterLabel
}
```

`CATEGORIES`、`TOOLS`、`RATINGS` 均定义为文件顶部的常量数组，扩展时直接修改这两个文件的常量即可（v2 的 TOOLS 比 v1 多了 Stitch 和 Tapnow）。

## 架构要点

`ai_practice_hub_v2.jsx` 是单文件组件，包含：

- **`StatCard`** — 数据看板的统计卡片
- **`MediaGallery`** — 图片/视频展示，支持 Before/After 双图对比布局
- **`CaseCard`** — 案例卡片，点击展开查看 Prompt，支持点赞
- **`ImageUploader`** — 使用 `FileReader` 将本地文件转为 base64 dataURL 预览（部署后需替换为服务端上传接口）
- **`App`（默认导出）** — 主应用，管理全局状态，包含四个 Tab：案例库、数据看板、提交案例、周报

所有状态（案例列表、筛选条件、表单数据）均为 React 本地状态（`useState`），**当前无持久化**。部署时需接入后端 API 替换 `DEMO_DATA` 和 `setCases` 逻辑。

## 待开发功能（来自需求文档）

- 后端 API + SQLite 数据持久化
- 邀请码登录验证
- 文件上传接口（替换当前的 base64 方案）

## 响应语言

代码注释和文档使用中文。
