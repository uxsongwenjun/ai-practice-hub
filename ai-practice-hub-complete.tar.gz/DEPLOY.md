# 部署到 GitHub 指南

## 📋 快速推送步骤

### 方案 A：使用 HTTPS（推荐，更方便）

#### 1️⃣ 在 GitHub 创建新仓库

访问 https://github.com/new，填写以下信息：

- **Repository name**: `ai-practice-hub`
- **Description**: AI 实践看板 - 设计团队 AI 使用案例平台
- **Visibility**: Public（公开）
- **Initialize this repository with**: 不勾选任何选项
- 点击 **Create repository**

#### 2️⃣ 生成 Personal Access Token

1. 访问 https://github.com/settings/tokens/new
2. 填写信息：
   - **Token name**: `ai-practice-hub-push`
   - **Expiration**: 根据需要选择（建议 90 days）
   - **Scopes**: 只勾选 `repo` 和 `write:packages`
3. 点击 **Generate token**
4. **复制 Token 值**（只显示一次！）

#### 3️⃣ 运行推送命令

```bash
cd /Users/junzi/Desktop/ai-practice-hub

# 设置远程仓库
git remote add origin https://github.com/uxsongwenjun/ai-practice-hub.git

# 验证远程配置
git remote -v

# 推送代码
git push -u origin main
```

**当提示输入密码时：**
- 用户名：你的 GitHub 用户名（如 uxsongwenjun）
- 密码：粘贴之前复制的 Personal Access Token

---

### 方案 B：使用 SSH（如果你已配置过 SSH）

如果你已经在 GitHub 账户中添加了 SSH 公钥：

```bash
cd /Users/junzi/Desktop/ai-practice-hub

# 设置远程仓库
git remote add origin git@github.com:uxsongwenjun/ai-practice-hub.git

# 推送代码
git push -u origin main
```

---

## 🔧 常见问题

### Q: 遇到 "fatal: remote origin already exists"

```bash
# 移除现有的 origin
git remote remove origin

# 重新添加
git remote add origin https://github.com/uxsongwenjun/ai-practice-hub.git
```

### Q: Token 过期了怎么办？

```bash
# 重新生成 token 后，更新本地配置
git remote set-url origin https://YOUR_NEW_TOKEN@github.com/uxsongwenjun/ai-practice-hub.git
```

### Q: 想切换回 HTTPS 方式

```bash
git remote set-url origin https://github.com/uxsongwenjun/ai-practice-hub.git
```

---

## ✅ 验证推送成功

推送完成后，访问以下链接验证：

https://github.com/uxsongwenjun/ai-practice-hub

你应该能看到：
- ✅ 所有代码文件
- ✅ Dockerfile 和 Docker 配置
- ✅ README.md 和文档
- ✅ 完整的 commit 历史

---

## 🐳 Docker 部署验证

推送到 GitHub 后，可以从任何地方拉取并运行：

```bash
# 克隆仓库
git clone https://github.com/uxsongwenjun/ai-practice-hub.git
cd ai-practice-hub

# 构建 Docker 镜像
docker build -t ai-practice-hub:latest .

# 运行容器
docker run -p 3000:3000 -v $(pwd)/data:/app/data ai-practice-hub:latest

# 访问应用
# http://localhost:3000
```

---

## 📝 推送后的下一步

1. ✅ 在 GitHub 上验证代码
2. ✅ 配置 GitHub Pages（可选）
3. ✅ 设置 GitHub Actions CI/CD（可选）
4. ✅ 邀请团队成员为 Collaborators
5. ✅ 配置分支保护规则（可选）

---

**完成后，你就可以与团队分享这个 GitHub 链接了！**
